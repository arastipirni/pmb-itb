# PROJECT PMB ITB - PHP + MySQL + XAMPP

## 1. Kegunaan project

Project ini adalah simulasi Aplikasi Pendaftaran Mahasiswa Baru
Institut Teknologi Bandung (ITB) dengan dua aktor utama:

- User: calon mahasiswa baru.
- Admin: pengelola dan pengawas data PMB.

Project dibuat agar dapat dibuka dan dipelajari melalui Visual Studio Code
serta dijalankan dengan Apache dan MySQL dari XAMPP.

## 2. Teknologi

- HTML
- CSS
- JavaScript
- PHP 8+
- MySQL / MariaDB
- XAMPP
- Visual Studio Code

## 3. Struktur file

```text
pmb_itb/
├── admin/
│   ├── login.php
│   ├── logout.php
│   ├── index.php
│   ├── applicants.php
│   ├── applicant_detail.php
│   ├── applicant_edit.php
│   ├── applicant_delete.php
│   ├── questions.php
│   ├── question_add.php
│   ├── question_edit.php
│   ├── question_delete.php
│   ├── majors.php
│   ├── major_add.php
│   ├── major_edit.php
│   ├── major_delete.php
│   ├── registrations.php
│   ├── announcements.php
│   ├── announcement_add.php
│   ├── announcement_edit.php
│   ├── announcement_delete.php
│   └── report.php
│
├── assets/
│   ├── css/
│   │   ├── style.css
│   │   └── admin.css
│   ├── js/
│   │   ├── app.js
│   │   └── admin.js
│   └── images/
│       └── itb-logo.png
│
├── auth/
│   ├── login.php
│   ├── register.php
│   └── logout.php
│
├── config/
│   ├── config.php
│   ├── helpers.php
│   └── auth.php
│
├── database/
│   └── database.sql
│
├── includes/
│   ├── header.php
│   ├── footer.php
│   ├── admin_header.php
│   └── admin_footer.php
│
├── user/
│   ├── index.php
│   ├── dashboard.php
│   ├── profile.php
│   ├── test.php
│   ├── submit_test.php
│   ├── result.php
│   ├── re-registration.php
│   └── card.php
│
├── index.php
└── README.md
```

## 4. Kegunaan folder dan file

### Folder `config`

`config.php`

Kegunaan: koneksi PHP ke database MySQL dan base URL project.

`helpers.php`

Kegunaan: fungsi umum seperti redirect, cek login, flash message,
nomor tes, dan NIM.

`auth.php`

Kegunaan: login, logout, session, dan activity log.

### Folder `auth`

`login.php`

Kegunaan: login calon mahasiswa.

`register.php`

Kegunaan: membuat akun calon mahasiswa baru.

`logout.php`

Kegunaan: keluar dari akun user.

### Folder `user`

`dashboard.php`

Kegunaan: pusat aktivitas calon mahasiswa.

`profile.php`

Kegunaan: melengkapi data diri dan memilih program studi.

`test.php`

Kegunaan: menampilkan soal tes.

`submit_test.php`

Kegunaan: menghitung jawaban benar, membuat skor, dan menetapkan status.

`result.php`

Kegunaan: melihat hasil tes.

`re-registration.php`

Kegunaan: mengirim pengajuan daftar ulang.

`card.php`

Kegunaan: menampilkan kartu penerimaan dan NIM setelah disetujui admin.

### Folder `admin`

`login.php`

Kegunaan: halaman login admin khusus.

`index.php`

Kegunaan: dashboard statistik admin.

`applicants.php`

Kegunaan: list seluruh calon mahasiswa serta pencarian.

`applicant_detail.php`

Kegunaan: melihat detail calon mahasiswa.

`applicant_edit.php`

Kegunaan: mengubah status, skor, dan NIM.

`applicant_delete.php`

Kegunaan: menghapus data calon mahasiswa.

`questions.php`

Kegunaan: daftar seluruh soal dan kunci jawaban.

`question_add.php`

Kegunaan: menambah soal baru.

`question_edit.php`

Kegunaan: mengubah soal dan kunci jawaban.

`question_delete.php`

Kegunaan: menghapus soal.

`majors.php`

Kegunaan: daftar program studi.

`major_add.php`

Kegunaan: menambah program studi.

`major_edit.php`

Kegunaan: mengubah program studi.

`major_delete.php`

Kegunaan: menghapus program studi.

`registrations.php`

Kegunaan: memeriksa daftar ulang dan membuat NIM saat disetujui.

`announcements.php`

Kegunaan: mengelola pengumuman.

`announcement_add.php`

Kegunaan: membuat pengumuman.

`announcement_edit.php`

Kegunaan: mengubah pengumuman.

`announcement_delete.php`

Kegunaan: menghapus pengumuman.

`report.php`

Kegunaan: melihat rekap pendaftaran, hasil tes, daftar ulang,
dan mahasiswa diterima.

### Folder `includes`

`header.php`

Kegunaan: template header dan navigasi User.

`footer.php`

Kegunaan: template footer.

`admin_header.php`

Kegunaan: template sidebar dan header Admin.

`admin_footer.php`

Kegunaan: penutup template Admin.

### Folder `assets`

`style.css`

Kegunaan: desain User.

`admin.css`

Kegunaan: desain Dashboard Admin.

`app.js`

Kegunaan: interaksi User, seperti menghilangkan notifikasi.

`admin.js`

Kegunaan: konfirmasi aksi hapus Admin.

`itb-logo.png`

Kegunaan: logo yang digunakan di halaman website.

### Folder `database`

`database.sql`

Kegunaan: membuat database, tabel, admin, jurusan, soal, dan pengumuman.

## 5. Cara menjalankan

### Langkah 1 - Pasang XAMPP

Install XAMPP, lalu buka XAMPP Control Panel.

Nyalakan:

- Apache
- MySQL

### Langkah 2 - Pindahkan project

Letakkan folder project ke:

```text
C:\xampp\htdocs\pmb_itb
```

### Langkah 3 - Import database

Buka:

```text
http://localhost/phpmyadmin
```

Klik Import, lalu pilih:

```text
database/database.sql
```

Klik Go.

### Langkah 4 - Jalankan website

Buka browser:

```text
http://localhost/pmb_itb/
```

### Langkah 5 - Login admin

Menu Admin tidak ditampilkan di navbar publik agar akses admin terpisah.
Untuk masuk sebagai admin, ketik URL berikut langsung di browser:

URL:

```text
http://localhost/pmb_itb/admin/login.php
```

Email:

```text
InstitutTeknologiBandung@gmail.com
```

Password:

```text
ITB123
```

## 6. Alur User

```text
Beranda
  |
  v
Registrasi
  |
  v
Login
  |
  v
Lengkapi Profil
  |
  v
Nomor Tes
  |
  v
Tes Seleksi
  |
  v
Hasil Tes
  |
  +---- Tidak Lulus
  |
  +---- Lulus
           |
           v
       Daftar Ulang
           |
           v
    Persetujuan Admin
           |
           v
      Mendapatkan NIM
           |
           v
        Kartu PMB
```

## 7. Alur Admin

```text
Login Admin
   |
   v
Dashboard Admin
   |
   +--> Calon Mahasiswa
   |
   +--> Bank Soal + Kunci
   |
   +--> Jurusan
   |
   +--> Daftar Ulang
   |
   +--> Pengumuman
   |
   +--> Laporan
```

## 8. Catatan tentang tampilan kode di VS Code

Semua file sengaja ditulis menggunakan format multi-line:

- Satu instruksi penting per baris.
- Indentasi 4 spasi.
- Komentar `Kegunaan:` di bagian atas file.
- Tidak dibuat satu baris panjang yang sulit dipahami.

Jika teks masih terlihat melebar di VS Code, gunakan:

```text
Alt + Z
```

Fitur tersebut adalah Word Wrap agar baris panjang turun ke bawah.

## 9. Catatan keamanan

Password admin pada database disimpan menggunakan `password_hash()`.
Password yang kamu gunakan untuk login tetap:

`ITB123`

Jangan menaruh password asli di file PHP ketika project akan dipakai
untuk sistem sungguhan.

## 10. Status project

Project ini dibuat sebagai project pembelajaran. Nama universitas telah
diperbaiki menjadi "Institut Teknologi Bandung (ITB)" dari typo pada
brief awal.


Pembaruan visual: tema biru dibuat lebih hidup dengan gradient, dekorasi bentuk geometris, kartu berbayang, aksen biru muda, dan footer yang lebih modern. Bank soal berisi 20 soal (10 kesiapan mahasiswa baru + 10 PPLG/RPL).


## Halaman Kontak User

User dapat membuka `contact.php` untuk mengirim pesan kepada Admin PMB. Pesan masuk ke tabel `contact_messages`. Admin membacanya melalui `admin/messages.php`, dapat menandai pesan sebagai sudah dibaca, dan menghapus pesan.

### Jika database `pmb_itb` sudah terlanjur dibuat
Untuk instalasi baru, cukup import `database/database.sql`. File tersebut sudah mencakup seluruh tabel PMB termasuk `contact_messages`, jadi tidak perlu import database kedua.


## Catatan Revisi Alur User

- Setelah profil tersimpan, peserta mendapatkan nomor tes. Sebelum soal dibuka, peserta harus mengetik nomor tes yang cocok dengan akun yang sedang login.
- Setelah ujian, peserta hanya melihat status seleksi, bukan angka skor. Skor tetap disimpan untuk penilaian internal dan dapat dilihat pengelola pada halaman admin.
- Pada halaman daftar ulang, peserta mengonfirmasi persetujuan melalui checkbox.
- Login admin terpisah dari navbar publik melalui `http://localhost/pmb_itb/admin/login.php`.


## 5. Akses Admin dan User secara bersamaan

Area Admin dan User memakai nama cookie session yang berbeda:

- Admin: `PMB_ITB_ADMIN_SESSID`, terbatas pada jalur `/pmb_itb/admin`.
- User: `PMB_ITB_USER_SESSID`, untuk jalur `/pmb_itb`.

Dengan pemisahan ini, akun Admin dan User dapat aktif bersamaan di tab atau URL yang berbeda. Logout Admin tidak menghapus sesi User, begitu pula sebaliknya.

- Halaman Admin: `http://localhost/pmb_itb/admin/`
- Halaman User: `http://localhost/pmb_itb/user/` (memerlukan user login; jika belum login akan diarahkan ke halaman login User).
- Login User: `http://localhost/pmb_itb/auth/login.php`
- Login Admin: `http://localhost/pmb_itb/admin/login.php`

Template navigasi `includes/header.php` dan `includes/admin_header.php` disertakan agar halaman yang memanggil template tersebut dapat dirender. Template Admin memeriksa sesi dan peran admin sebelum menampilkan halaman pengelolaan.

