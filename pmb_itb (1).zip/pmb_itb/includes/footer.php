<?php
/**
 * Kegunaan: Menampilkan footer lengkap website dan menutup dokumen HTML.
 */
?>
    </div>
</main>

<footer class="site-footer">
    <div class="container footer-main">
        <div>
            <div class="footer-brand">
                <img
                    src="<?= $baseUrl ?>/assets/images/itb-logo.png"
                    alt="Logo ITB"
                >
                <div>
                    <strong>PMB ITB</strong>
                    <small>Pendaftaran Mahasiswa Baru</small>
                </div>
            </div>
            <p>
                Pendaftaran Mahasiswa Baru Institut Teknologi Bandung
                untuk membantu calon mahasiswa mengikuti proses 
                registrasi, seleksi, pengumuman hasil, hingga daftar ulang.
            </p>
        </div>

        <div>
            <h3>Menu</h3>
            <div class="footer-links">
                <a href="<?= $baseUrl ?>/index.php">Beranda</a>
                <a href="<?= $baseUrl ?>/index.php#alur">Alur PMB</a>
                <a href="<?= $baseUrl ?>/auth/register.php">Registrasi</a>
                <a href="<?= $baseUrl ?>/auth/login.php">Login</a>
                <a href="<?= $baseUrl ?>/contact.php">Kontak</a>
            </div>
        </div>

        <div>
            <h3>Layanan Pendaftar</h3>
            <div class="footer-links">
                <a href="<?= $baseUrl ?>/user/dashboard.php">Dashboard</a>
                <a href="<?= $baseUrl ?>/user/profile.php">Profil</a>
                <a href="<?= $baseUrl ?>/user/announcements.php">Pengumuman</a>
                <a href="<?= $baseUrl ?>/contact.php">Hubungi Admin</a>
            </div>
        </div>

        <div>
            <h3>Kontak Project</h3>
            <p>InstitutTeknologiBandung@gmail.com</p>
            <p>Jam layanan: Senin–Jumat</p>
            <p>08.00–16.00 WIB</p>
        </div>
    </div>

    <div class="container footer-bottom">
        <span>
            &copy; <?= date('Y') ?> PMB ITB. Project Pendaftaran Mahasiswa Baru.
        </span>
    </div>
</footer>
</body>
</html>
