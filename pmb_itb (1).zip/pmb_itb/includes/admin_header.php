<?php
/**
 * Kegunaan: Navigasi dan pembatas akses untuk seluruh halaman Admin.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$pageTitle = $pageTitle ?? 'Panel Admin';
$activeFile = basename($_SERVER['SCRIPT_NAME'] ?? 'index.php');
$successMessage = flash('success');
$errorMessage = flash('error');

$adminMenu = [
    'index.php' => 'Dashboard',
    'applicants.php' => 'Calon Mahasiswa',
    'questions.php' => 'Bank Soal Tes',
    'majors.php' => 'Kelola Jurusan',
    'registrations.php' => 'Daftar Ulang',
    'announcements.php' => 'Pengumuman',
    'messages.php' => 'Pesan User',
    'report.php' => 'Laporan PMB',
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#073477">
    <title><?= e($pageTitle) ?> | Admin PMB ITB</title>
    <link rel="stylesheet" href="/pmb_itb/assets/css/style.css">
    <link rel="stylesheet" href="/pmb_itb/assets/css/admin.css">
    <script src="/pmb_itb/assets/js/admin.js" defer></script>
</head>
<body class="admin-body">
<div class="admin-layout">
    <aside class="admin-sidebar">
        <a class="admin-brand" href="/pmb_itb/admin/index.php">
            <img src="/pmb_itb/assets/images/itb-logo.png" alt="Logo ITB">
            <span>
                <strong>PMB ITB</strong>
                <small>Panel Admin</small>
            </span>
        </a>
        <nav class="admin-menu" aria-label="Menu admin">
            <?php foreach ($adminMenu as $file => $label): ?>
                <a href="<?= e($file) ?>" class="<?= $activeFile === $file ? 'active' : '' ?>" <?= $activeFile === $file ? 'aria-current="page"' : '' ?>>
                    <span><?= e($label) ?></span>
                </a>
            <?php endforeach; ?>
            <a class="logout-link" href="/pmb_itb/admin/logout.php"><span>Logout Admin</span></a>
        </nav>
    </aside>
    <section class="admin-content">
        <header class="admin-topbar">
            <div>
                <small>Login sebagai</small>
                <strong><?= e($_SESSION['name'] ?? 'Administrator') ?></strong>
            </div>
        </header>
        <div class="admin-page-title">
            <h1><?= e($pageTitle) ?></h1>
        </div>
        <?php if ($successMessage): ?>
            <div class="alert success" role="status"><?= e($successMessage) ?></div>
        <?php endif; ?>
        <?php if ($errorMessage): ?>
            <div class="alert error" role="alert"><?= e($errorMessage) ?></div>
        <?php endif; ?>
