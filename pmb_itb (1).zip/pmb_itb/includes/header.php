<?php
/**
 * Kegunaan: Header dan navigasi bersama untuk halaman publik dan user.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';

$pageTitle = $pageTitle ?? 'PMB ITB';
$loggedIn = is_logged_in() && !is_admin();
$successMessage = flash('success');
$errorMessage = flash('error');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#073477">
    <title><?= e($pageTitle) ?> | PMB ITB</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
    <script src="<?= $baseUrl ?>/assets/js/app.js" defer></script>
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="<?= $baseUrl ?>/index.php" aria-label="PMB ITB Beranda">
            <img src="<?= $baseUrl ?>/assets/images/itb-logo.png" alt="Logo PMB ITB">
            <span>
                <strong>PMB ITB</strong>
                <small>Pendaftaran Mahasiswa Baru</small>
            </span>
        </a>
        <nav class="main-nav" aria-label="Navigasi utama">
            <a href="<?= $baseUrl ?>/index.php">Beranda</a>
            <a href="<?= $baseUrl ?>/index.php#alur">Alur PMB</a>
            <a href="<?= $baseUrl ?>/contact.php">Kontak</a>
            <?php if ($loggedIn): ?>
                <a href="<?= $baseUrl ?>/user/dashboard.php">Dashboard</a>
                <a href="<?= $baseUrl ?>/user/profile.php">Profil</a>
                <a class="btn primary" href="<?= $baseUrl ?>/auth/logout.php">Logout User</a>
            <?php else: ?>
                <a href="<?= $baseUrl ?>/auth/login.php">Login User</a>
                <a class="btn primary" href="<?= $baseUrl ?>/auth/register.php">Daftar</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="page-main">
    <div class="container">
        <?php if ($successMessage): ?>
            <div class="alert success" role="status"><?= e($successMessage) ?></div>
        <?php endif; ?>
        <?php if ($errorMessage): ?>
            <div class="alert error" role="alert"><?= e($errorMessage) ?></div>
        <?php endif; ?>
