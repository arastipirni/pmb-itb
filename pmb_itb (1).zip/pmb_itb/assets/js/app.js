/*
 * Kegunaan: Interaksi umum website User, termasuk auto-hide alert
 * dan penandaan opsi jawaban yang sedang dipilih.
 */

document.addEventListener('DOMContentLoaded', function () {
    var alerts = document.querySelectorAll('.alert');

    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.classList.add('hide');
        }, 6000);
    });

    var optionInputs = document.querySelectorAll(
        '.option-row input[type="radio"]'
    );

    optionInputs.forEach(function (input) {
        input.addEventListener('change', function () {
            var name = input.getAttribute('name');
            var group = document.querySelectorAll(
                'input[name="' + name + '"]'
            );

            group.forEach(function (item) {
                item.closest('.option-row').classList.remove('selected');
            });

            input.closest('.option-row').classList.add('selected');
        });
    });
});
