/*
 * Kegunaan: Menjalankan timer tes, menyimpan waktu akhir di localStorage,
 * dan mengirim jawaban otomatis saat waktu habis.
 */

document.addEventListener('DOMContentLoaded', function () {
    var timer = document.querySelector('[data-test-timer]');
    var form = document.querySelector('[data-test-form]');

    if (!timer || !form) {
        return;
    }

    var duration = Number(timer.dataset.duration || 1800);
    var storageKey = 'pmb_itb_exam_end_' + (timer.dataset.testNumber || 'test');
    var savedEnd = Number(localStorage.getItem(storageKey) || 0);
    var endTime = savedEnd > Date.now()
        ? savedEnd
        : Date.now() + duration * 1000;

    localStorage.setItem(storageKey, String(endTime));

    function pad(value) {
        return String(value).padStart(2, '0');
    }

    function render() {
        var remaining = Math.max(0, endTime - Date.now());
        var seconds = Math.floor(remaining / 1000);
        var minutes = Math.floor(seconds / 60);
        var restSeconds = seconds % 60;

        timer.querySelector('[data-minutes]').textContent = pad(minutes);
        timer.querySelector('[data-seconds]').textContent = pad(restSeconds);

        if (seconds <= 300) {
            timer.classList.add('warning');
        }

        if (seconds <= 60) {
            timer.classList.remove('warning');
            timer.classList.add('danger');
        }

        if (remaining <= 0) {
            localStorage.removeItem(storageKey);
            var hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'expired';
            hidden.value = '1';
            form.appendChild(hidden);
            form.submit();
            return;
        }

        window.setTimeout(render, 1000);
    }

    render();

    form.addEventListener('submit', function () {
        localStorage.removeItem(storageKey);
    });
});
