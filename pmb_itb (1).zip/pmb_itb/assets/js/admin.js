/*
 * Kegunaan: Konfirmasi sebelum aksi hapus data di area Admin.
 */

document.addEventListener('DOMContentLoaded', function () {
    var links = document.querySelectorAll('[data-confirm]');

    links.forEach(function (link) {
        link.addEventListener('click', function (event) {
            var message = link.getAttribute('data-confirm');

            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
});
