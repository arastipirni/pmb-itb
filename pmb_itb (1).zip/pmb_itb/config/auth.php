<?php
/**
 * Kegunaan: Fungsi login, logout, dan pencatatan aktivitas pengguna.
 */

function login_user($user)
{
    session_regenerate_id(true);

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
}

function logout_user()
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}

function log_activity($conn, $userId, $action)
{
    $stmt = $conn->prepare(
        'INSERT INTO activity_logs (user_id, action) VALUES (?, ?)'
    );

    $stmt->bind_param('is', $userId, $action);
    $stmt->execute();
}
?>
