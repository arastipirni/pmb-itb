<?php
/**
 * Kegunaan: Berisi fungsi umum yang dipakai oleh halaman User dan Admin.
 */

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

function is_logged_in()
{
    return isset($_SESSION['user_id']);
}

function is_admin()
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function require_login()
{
    if (!is_logged_in()) {
        redirect('/pmb_itb/auth/login.php');
    }
}

function require_admin()
{
    if (!is_logged_in() || !is_admin()) {
        redirect('/pmb_itb/admin/login.php');
    }
}

function flash($key, $message = null)
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }

    $result = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $result;
}


function ensure_application($conn, $userId)
{
    $userId = (int) $userId;

    $stmt = $conn->prepare(
        'SELECT id FROM applications WHERE user_id = ? LIMIT 1'
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    if ($row) {
        return (int) $row['id'];
    }

    $stmt = $conn->prepare(
        'INSERT INTO applications (user_id, status) VALUES (?, "registered")'
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();

    return (int) $conn->insert_id;
}

function generate_test_number($conn)
{
    $prefix = 'ITB-TEST-' . date('Y');

    $stmt = $conn->prepare(
        'SELECT COUNT(*) AS total FROM applications WHERE test_number LIKE ?'
    );

    $pattern = $prefix . '-%';
    $stmt->bind_param('s', $pattern);
    $stmt->execute();

    $row = $stmt->get_result()->fetch_assoc();
    $number = (int) $row['total'] + 1;

    return $prefix . '-' . str_pad($number, 5, '0', STR_PAD_LEFT);
}

function generate_nim($conn)
{
    $year = date('y');
    $base = '2' . $year;

    $stmt = $conn->prepare(
        'SELECT COUNT(*) AS total FROM applications WHERE nim LIKE ?'
    );

    $pattern = $base . '%';
    $stmt->bind_param('s', $pattern);
    $stmt->execute();

    $row = $stmt->get_result()->fetch_assoc();
    $number = (int) $row['total'] + 1;

    return $base . str_pad($number, 6, '0', STR_PAD_LEFT);
}

function status_badge($status)
{
    $map = [
        'registered' => 'Terdaftar',
        'tested' => 'Sudah Tes',
        'passed' => 'Lulus',
        'failed' => 'Tidak Lulus',
        're_registered' => 'Daftar Ulang',
        'accepted' => 'Diterima',
    ];

    return $map[$status] ?? ucfirst($status);
}
?>
