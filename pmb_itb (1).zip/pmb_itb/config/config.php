<?php
/**
 * Kegunaan: Mengatur koneksi database dan konfigurasi dasar aplikasi.
 */

// Pisahkan cookie session untuk area admin dan user.
// Admin hanya menerima cookie di /pmb_itb/admin, sedangkan user di /pmb_itb.
// Nama session yang berbeda mencegah login satu area menimpa area lainnya.
$requestPath = parse_url(
    $_SERVER['REQUEST_URI'] ?? $_SERVER['SCRIPT_NAME'] ?? '/',
    PHP_URL_PATH
);
$requestPath = is_string($requestPath) ? $requestPath : '/';
$isAdminArea = preg_match('~(?:^|/)admin(?:/|$)~', $requestPath) === 1;

if (session_status() === PHP_SESSION_NONE) {
    $sessionCookiePath = $isAdminArea ? '/pmb_itb/admin' : '/pmb_itb';
    $sessionName = $isAdminArea
        ? 'PMB_ITB_ADMIN_SESSID'
        : 'PMB_ITB_USER_SESSID';

    session_name($sessionName);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => $sessionCookiePath,
        'secure' => !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

date_default_timezone_set('Asia/Jakarta');

$dbHost = 'localhost';
$dbName = 'pmb_itb';
$dbUser = 'root';
$dbPass = '';

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    die('Koneksi database gagal: ' . $conn->connect_error);
}

$conn->set_charset('utf8mb4');

$baseUrl = '/pmb_itb';
?>
