<?php
/**
 * Kegunaan: Menghapus soal dari bank soal.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare('DELETE FROM questions WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();

flash('success', 'Soal berhasil dihapus.');
redirect('/pmb_itb/admin/questions.php');
?>
