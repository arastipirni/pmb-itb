<?php
/**
 * Kegunaan: Menampilkan ringkasan statistik dan tabel laporan PMB.
 */

$pageTitle = 'Laporan PMB';
require_once __DIR__ . '/../includes/admin_header.php';

$report = $conn->query(
    'SELECT '
    . 'SUM(status = "registered") AS registered, '
    . 'SUM(status = "tested") AS tested, '
    . 'SUM(status = "passed") AS passed, '
    . 'SUM(status = "failed") AS failed, '
    . 'SUM(status = "re_registered") AS re_registered, '
    . 'SUM(status = "accepted") AS accepted '
    . 'FROM applications'
)->fetch_assoc();

$recent = $conn->query(
    'SELECT u.name, u.email, a.status, a.test_score, a.nim '
    . 'FROM applications a '
    . 'JOIN users u ON u.id = a.user_id '
    . 'ORDER BY a.updated_at DESC LIMIT 20'
);
?>

<div class="stat-grid">
    <div class="stat-card">
        <span>Terdaftar</span>
        <strong><?= e($report['registered']) ?></strong>
    </div>
    <div class="stat-card">
        <span>Sudah Tes</span>
        <strong><?= e($report['tested']) ?></strong>
    </div>
    <div class="stat-card">
        <span>Lulus</span>
        <strong><?= e($report['passed']) ?></strong>
    </div>
    <div class="stat-card">
        <span>Tidak Lulus</span>
        <strong><?= e($report['failed']) ?></strong>
    </div>
    <div class="stat-card">
        <span>Daftar Ulang</span>
        <strong><?= e($report['re_registered']) ?></strong>
    </div>
    <div class="stat-card">
        <span>Diterima</span>
        <strong><?= e($report['accepted']) ?></strong>
    </div>
</div>

<section class="admin-panel">
    <h2>20 Data Terbaru</h2>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Skor</th>
                    <th>NIM</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $recent->fetch_assoc()): ?>
                    <tr>
                        <td><?= e($row['name']) ?></td>
                        <td><?= e($row['email']) ?></td>
                        <td><?= e(status_badge($row['status'])) ?></td>
                        <td><?= e($row['test_score']) ?></td>
                        <td><?= e($row['nim']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
