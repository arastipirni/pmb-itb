<?php
/**
 * Kegunaan: Menampilkan bank soal dan menyediakan CRUD soal.
 */

$pageTitle = 'Bank Soal Tes';
require_once __DIR__ . '/../includes/admin_header.php';

$questions = $conn->query(
    'SELECT * FROM questions ORDER BY id DESC'
);
?>

<section class="admin-panel">
    <div class="toolbar">
        <a class="btn primary" href="question_add.php">
            + Tambah Soal
        </a>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Pertanyaan</th>
                    <th>Kunci</th>
                    <th>Aktif</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php while ($q = $questions->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= e($q['question']) ?></td>
                        <td><?= strtoupper(e($q['correct_answer'])) ?></td>
                        <td><?= $q['is_active'] ? 'Ya' : 'Tidak' ?></td>
                        <td class="actions">
                            <a class="action-btn edit-btn" href="question_edit.php?id=<?= $q['id'] ?>">
                                Edit
                            </a>
                            <a
                                class="action-btn delete-btn danger-link"
                                href="question_delete.php?id=<?= $q['id'] ?>"
                                data-confirm="Hapus soal ini?"
                            >
                                Hapus
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
