<?php
/**
 * Kegunaan: Menampilkan dan mengelola pengumuman PMB.
 */

$pageTitle = 'Pengumuman';
require_once __DIR__ . '/../includes/admin_header.php';

$items = $conn->query(
    'SELECT * FROM announcements ORDER BY created_at DESC'
);
?>

<section class="admin-panel">
    <div class="toolbar">
        <a class="btn primary" href="announcement_add.php">
            + Tambah Pengumuman
        </a>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Isi</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $items->fetch_assoc()): ?>
                    <tr>
                        <td><?= e($row['title']) ?></td>
                        <td><?= e($row['content']) ?></td>
                        <td>
                            <?= $row['is_active'] ? 'Aktif' : 'Nonaktif' ?>
                        </td>
                        <td class="actions">
                            <a class="action-btn edit-btn" href="announcement_edit.php?id=<?= $row['id'] ?>">
                                Edit
                            </a>
                            <a
                                class="action-btn delete-btn danger-link"
                                href="announcement_delete.php?id=<?= $row['id'] ?>"
                                data-confirm="Hapus pengumuman ini?"
                            >
                                Hapus
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
