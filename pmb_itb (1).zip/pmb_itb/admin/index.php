<?php
/**
 * Kegunaan: Dashboard utama Admin untuk memantau statistik PMB.
 */

$pageTitle = 'Dashboard Admin';
require_once __DIR__ . '/../includes/admin_header.php';

$totalUsers = $conn->query(
    'SELECT COUNT(*) AS total FROM users WHERE role = "user"'
)->fetch_assoc()['total'];

$totalPassed = $conn->query(
    'SELECT COUNT(*) AS total FROM applications WHERE status = "passed"'
)->fetch_assoc()['total'];

$totalFailed = $conn->query(
    'SELECT COUNT(*) AS total FROM applications WHERE status = "failed"'
)->fetch_assoc()['total'];

$totalReReg = $conn->query(
    'SELECT COUNT(*) AS total FROM re_registrations '
    . 'WHERE status = "submitted"'
)->fetch_assoc()['total'];

$totalUnreadMessages = $conn->query(
    'SELECT COUNT(*) AS total FROM contact_messages WHERE status = "unread"'
)->fetch_assoc()['total'];
?>

<div class="stat-grid">
    <div class="stat-card">
        <span>Total Calon Maba</span>
        <strong><?= e($totalUsers) ?></strong>
    </div>

    <div class="stat-card">
        <span>Lulus Tes</span>
        <strong><?= e($totalPassed) ?></strong>
    </div>

    <div class="stat-card">
        <span>Tidak Lulus</span>
        <strong><?= e($totalFailed) ?></strong>
    </div>

    <div class="stat-card">
        <span>Menunggu Daftar Ulang</span>
        <strong><?= e($totalReReg) ?></strong>
    </div>

    <div class="stat-card message-stat">
        <span>Pesan Belum Dibaca</span>
        <strong><?= e($totalUnreadMessages) ?></strong>
    </div>
</div>

<div class="admin-grid-two">
    <section class="admin-panel">
        <h2>Menu Pengelolaan</h2>
        <div class="admin-link-grid">
            <a href="applicants.php"><span class="quick-icon">👤</span><span>Kelola Calon Mahasiswa</span></a>
            <a href="questions.php"><span class="quick-icon">☑</span><span>Kelola Bank Soal</span></a>
            <a href="majors.php"><span class="quick-icon">🎓</span><span>Kelola Jurusan</span></a>
            <a href="registrations.php"><span class="quick-icon">↻</span><span>Kelola Daftar Ulang</span></a>
            <a href="announcements.php"><span class="quick-icon">🔔</span><span>Kelola Pengumuman</span></a>
            <a href="report.php"><span class="quick-icon">▤</span><span>Lihat Laporan</span></a>
            <a href="messages.php"><span class="quick-icon">✉</span><span>Lihat Pesan User</span></a>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
