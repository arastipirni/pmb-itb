<?php
/**
 * Kegunaan: Menambah pengumuman yang dapat dibaca calon mahasiswa.
 */

$pageTitle = 'Tambah Pengumuman';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');

    $stmt = $conn->prepare(
        'INSERT INTO announcements (title, content) VALUES (?, ?)'
    );
    $stmt->bind_param('ss', $title, $content);
    $stmt->execute();

    flash('success', 'Pengumuman berhasil ditambahkan.');
    redirect('/pmb_itb/admin/announcements.php');
}
?>

<section class="admin-panel narrow-admin-panel">
    <form method="post" class="form-stack">
        <label>
            Judul
            <input type="text" name="title" required>
        </label>

        <label>
            Isi Pengumuman
            <textarea name="content" rows="7" required></textarea>
        </label>

        <button class="btn primary" type="submit">
            Simpan Pengumuman
        </button>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
