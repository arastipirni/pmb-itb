<?php
/**
 * Kegunaan: Login khusus Admin PMB ITB.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/auth.php';

if (is_logged_in() && is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare(
        'SELECT id, name, email, password, role '
        . 'FROM users WHERE email = ? AND role = "admin" LIMIT 1'
    );

    $stmt->bind_param('s', $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        login_user($user);
        log_activity($conn, $user['id'], 'Login admin');
        redirect('/pmb_itb/admin/index.php');
    }

    $error = 'Login admin gagal. Periksa email dan password.';
}

$pageTitle = 'Login Admin';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="auth-layout">
    <div class="auth-card">
        <span class="eyebrow">Area Privat</span>
        <h1>Login Admin</h1>
        <p>
            Halaman ini khusus untuk pengelola data PMB.
        </p>

        <?php if ($error): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" class="form-stack">
            <label>
                Email Admin
                <input
                    type="email"
                    name="email"
                    required
                >
            </label>

            <label>
                Password Admin
                <input
                    type="password"
                    name="password"
                    required
                >
            </label>

            <button class="btn primary" type="submit">
                Masuk Dashboard Admin
            </button>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
