<?php
/**
 * Kegunaan: Mengubah status, skor, dan data penting calon mahasiswa.
 */

$pageTitle = 'Edit Calon Mahasiswa';
require_once __DIR__ . '/../includes/admin_header.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare(
    'SELECT a.*, u.name, u.email FROM applications a '
    . 'JOIN users u ON u.id = a.user_id '
    . 'WHERE a.id = ? LIMIT 1'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    flash('error', 'Data tidak ditemukan.');
    redirect('/pmb_itb/admin/applicants.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'] ?? 'registered';
    $score = (int) ($_POST['test_score'] ?? 0);
    $nim = trim($_POST['nim'] ?? '');

    $stmt = $conn->prepare(
        'UPDATE applications SET status = ?, test_score = ?, nim = ? '
        . 'WHERE id = ?'
    );
    $stmt->bind_param('sisi', $status, $score, $nim, $id);
    $stmt->execute();

    flash('success', 'Data calon mahasiswa berhasil diubah.');
    redirect('/pmb_itb/admin/applicants.php');
}
?>

<section class="admin-panel narrow-admin-panel">
    <form method="post" class="form-stack">
        <label>
            Nama
            <input value="<?= e($data['name']) ?>" disabled>
        </label>

        <label>
            Status
            <select name="status">
                <?php foreach ([
                    'registered' => 'Terdaftar',
                    'tested' => 'Sudah Tes',
                    'passed' => 'Lulus',
                    'failed' => 'Tidak Lulus',
                    're_registered' => 'Daftar Ulang',
                    'accepted' => 'Diterima',
                ] as $value => $label): ?>
                    <option
                        value="<?= e($value) ?>"
                        <?= $data['status'] === $value ? 'selected' : '' ?>
                    >
                        <?= e($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>
            Skor Tes
            <input
                type="number"
                name="test_score"
                min="0"
                max="100"
                value="<?= e($data['test_score']) ?>"
            >
        </label>

        <label>
            NIM
            <input
                type="text"
                name="nim"
                value="<?= e($data['nim']) ?>"
            >
        </label>

        <button class="btn primary" type="submit">
            Simpan Perubahan
        </button>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
