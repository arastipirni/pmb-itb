<?php
/**
 * Kegunaan: Menambahkan soal baru beserta kunci jawaban.
 */

$pageTitle = 'Tambah Soal';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = trim($_POST['question'] ?? '');
    $a = trim($_POST['option_a'] ?? '');
    $b = trim($_POST['option_b'] ?? '');
    $c = trim($_POST['option_c'] ?? '');
    $d = trim($_POST['option_d'] ?? '');
    $correct = $_POST['correct_answer'] ?? 'a';

    $stmt = $conn->prepare(
        'INSERT INTO questions '
        . '(question, option_a, option_b, option_c, option_d, correct_answer) '
        . 'VALUES (?, ?, ?, ?, ?, ?)'
    );
    $stmt->bind_param('ssssss', $question, $a, $b, $c, $d, $correct);
    $stmt->execute();

    flash('success', 'Soal berhasil ditambahkan.');
    redirect('/pmb_itb/admin/questions.php');
}
?>

<section class="admin-panel narrow-admin-panel">
    <form method="post" class="form-stack">
        <label>
            Pertanyaan
            <textarea name="question" rows="5" required></textarea>
        </label>

        <label>
            Pilihan A
            <input type="text" name="option_a" required>
        </label>

        <label>
            Pilihan B
            <input type="text" name="option_b" required>
        </label>

        <label>
            Pilihan C
            <input type="text" name="option_c" required>
        </label>

        <label>
            Pilihan D
            <input type="text" name="option_d" required>
        </label>

        <label>
            Kunci Jawaban
            <select name="correct_answer">
                <option value="a">A</option>
                <option value="b">B</option>
                <option value="c">C</option>
                <option value="d">D</option>
            </select>
        </label>

        <button class="btn primary" type="submit">
            Simpan Soal
        </button>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
