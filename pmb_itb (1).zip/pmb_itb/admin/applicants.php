<?php
/**
 * Kegunaan: Menampilkan seluruh calon mahasiswa dan menyediakan aksi CRUD.
 */

$pageTitle = 'Kelola Calon Mahasiswa';
require_once __DIR__ . '/../includes/admin_header.php';

$keyword = trim($_GET['q'] ?? '');

$sql =
    'SELECT a.id, a.user_id, a.test_number, a.status, a.test_score, '
    . 'a.nim, u.name, u.email, m.name AS major_name '
    . 'FROM applications a '
    . 'JOIN users u ON u.id = a.user_id '
    . 'LEFT JOIN majors m ON m.id = a.major_id ';

if ($keyword !== '') {
    $sql .= 'WHERE u.name LIKE ? OR u.email LIKE ? '
        . 'OR a.test_number LIKE ? ';
}

$sql .= 'ORDER BY a.created_at DESC';

if ($keyword !== '') {
    $stmt = $conn->prepare($sql);
    $pattern = '%' . $keyword . '%';
    $stmt->bind_param('sss', $pattern, $pattern, $pattern);
    $stmt->execute();
    $rows = $stmt->get_result();
} else {
    $rows = $conn->query($sql);
}
?>

<section class="admin-panel">
    <div class="toolbar">
        <form method="get" class="search-form">
            <input
                type="search"
                name="q"
                value="<?= e($keyword) ?>"
                placeholder="Cari nama, email, atau nomor tes"
            >
            <button class="btn primary" type="submit">Cari</button>
        </form>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Nomor Tes</th>
                    <th>Jurusan</th>
                    <th>Skor</th>
                    <th>Status</th>
                    <th>NIM</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $rows->fetch_assoc()): ?>
                    <tr>
                        <td><?= e($row['name']) ?></td>
                        <td><?= e($row['email']) ?></td>
                        <td><?= e($row['test_number']) ?></td>
                        <td><?= e($row['major_name']) ?></td>
                        <td><?= e($row['test_score']) ?></td>
                        <td>
                            <span class="badge">
                                <?= e(status_badge($row['status'])) ?>
                            </span>
                        </td>
                        <td><?= e($row['nim']) ?></td>
                        <td class="actions">
                            <a class="action-btn detail-btn" href="applicant_detail.php?id=<?= $row['id'] ?>">
                                Detail
                            </a>
                            <a class="action-btn edit-btn" href="applicant_edit.php?id=<?= $row['id'] ?>">
                                Edit
                            </a>
                            <a
                                class="action-btn delete-btn danger-link"
                                href="applicant_delete.php?id=<?= $row['id'] ?>"
                                data-confirm="Hapus calon mahasiswa ini?"
                            >
                                Hapus
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
