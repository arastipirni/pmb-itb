<?php
/**
 * Kegunaan: Mengubah data program studi.
 */

$pageTitle = 'Edit Jurusan';
require_once __DIR__ . '/../includes/admin_header.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare('SELECT * FROM majors WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    flash('error', 'Jurusan tidak ditemukan.');
    redirect('/pmb_itb/admin/majors.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['code'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $faculty = trim($_POST['faculty'] ?? '');

    $stmt = $conn->prepare(
        'UPDATE majors SET code = ?, name = ?, faculty = ? WHERE id = ?'
    );
    $stmt->bind_param('sssi', $code, $name, $faculty, $id);
    $stmt->execute();

    flash('success', 'Jurusan berhasil diperbarui.');
    redirect('/pmb_itb/admin/majors.php');
}
?>

<section class="admin-panel narrow-admin-panel">
    <form method="post" class="form-stack">
        <label>
            Kode
            <input
                type="text"
                name="code"
                value="<?= e($data['code']) ?>"
                required
            >
        </label>

        <label>
            Program Studi
            <input
                type="text"
                name="name"
                value="<?= e($data['name']) ?>"
                required
            >
        </label>

        <label>
            Fakultas / Sekolah
            <input
                type="text"
                name="faculty"
                value="<?= e($data['faculty']) ?>"
                required
            >
        </label>

        <button class="btn primary" type="submit">
            Simpan Perubahan
        </button>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
