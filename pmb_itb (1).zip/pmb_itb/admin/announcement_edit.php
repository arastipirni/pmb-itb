<?php
/**
 * Kegunaan: Mengubah isi dan status pengumuman.
 */

$pageTitle = 'Edit Pengumuman';
require_once __DIR__ . '/../includes/admin_header.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare(
    'SELECT * FROM announcements WHERE id = ? LIMIT 1'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    flash('error', 'Pengumuman tidak ditemukan.');
    redirect('/pmb_itb/admin/announcements.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $active = isset($_POST['is_active']) ? 1 : 0;

    $stmt = $conn->prepare(
        'UPDATE announcements SET title = ?, content = ?, '
        . 'is_active = ? WHERE id = ?'
    );
    $stmt->bind_param('ssii', $title, $content, $active, $id);
    $stmt->execute();

    flash('success', 'Pengumuman berhasil diperbarui.');
    redirect('/pmb_itb/admin/announcements.php');
}
?>

<section class="admin-panel narrow-admin-panel">
    <form method="post" class="form-stack">
        <label>
            Judul
            <input
                type="text"
                name="title"
                value="<?= e($data['title']) ?>"
                required
            >
        </label>

        <label>
            Isi Pengumuman
            <textarea name="content" rows="7" required><?= e(
                $data['content']
            ) ?></textarea>
        </label>

        <label class="check-row">
            <input
                type="checkbox"
                name="is_active"
                <?= $data['is_active'] ? 'checked' : '' ?>
            >
            Tampilkan pengumuman
        </label>

        <button class="btn primary" type="submit">
            Simpan Perubahan
        </button>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
