<?php
/**
 * Kegunaan: Menghapus data calon mahasiswa dan akun user terkait.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare(
    'SELECT user_id FROM applications WHERE id = ? LIMIT 1'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if ($data) {
    $userId = (int) $data['user_id'];

    $stmt = $conn->prepare('DELETE FROM users WHERE id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();

    flash('success', 'Data calon mahasiswa berhasil dihapus.');
}

redirect('/pmb_itb/admin/applicants.php');
?>
