<?php
/**
 * Kegunaan: Mengelola daftar program studi yang tersedia pada aplikasi.
 */

$pageTitle = 'Kelola Jurusan';
require_once __DIR__ . '/../includes/admin_header.php';

$majors = $conn->query(
    'SELECT * FROM majors ORDER BY faculty, name'
);
?>

<section class="admin-panel">
    <div class="toolbar">
        <a class="btn primary" href="major_add.php">
            + Tambah Jurusan
        </a>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Program Studi</th>
                    <th>Fakultas/Sekolah</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($major = $majors->fetch_assoc()): ?>
                    <tr>
                        <td><?= e($major['code']) ?></td>
                        <td><?= e($major['name']) ?></td>
                        <td><?= e($major['faculty']) ?></td>
                        <td class="actions">
                            <a class="action-btn edit-btn" href="major_edit.php?id=<?= $major['id'] ?>">
                                Edit
                            </a>
                            <a
                                class="action-btn delete-btn danger-link"
                                href="major_delete.php?id=<?= $major['id'] ?>"
                                data-confirm="Hapus jurusan ini?"
                            >
                                Hapus
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
