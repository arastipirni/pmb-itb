<?php
/**
 * Kegunaan: Logout khusus admin.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/auth.php';

logout_user();

header('Location: /pmb_itb/admin/login.php');
exit;
?>
