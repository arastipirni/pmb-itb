<?php
/**
 * Kegunaan: Menampilkan detail lengkap satu calon mahasiswa.
 */

$pageTitle = 'Detail Calon Mahasiswa';
require_once __DIR__ . '/../includes/admin_header.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare(
    'SELECT u.name, u.email, a.*, m.name AS major_name, m.faculty '
    . 'FROM applications a '
    . 'JOIN users u ON u.id = a.user_id '
    . 'LEFT JOIN majors m ON m.id = a.major_id '
    . 'WHERE a.id = ? LIMIT 1'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    flash('error', 'Data tidak ditemukan.');
    redirect('/pmb_itb/admin/applicants.php');
}
?>

<section class="admin-panel">
    <div class="data-grid two">
        <div><span>Nama</span><strong><?= e($data['name']) ?></strong></div>
        <div><span>Email</span><strong><?= e($data['email']) ?></strong></div>
        <div><span>Nomor Tes</span><strong><?= e($data['test_number']) ?></strong></div>
        <div><span>Status</span><strong><?= e(status_badge($data['status'])) ?></strong></div>
        <div><span>Skor</span><strong><?= e($data['test_score']) ?></strong></div>
        <div><span>NIM</span><strong><?= e($data['nim']) ?></strong></div>
        <div><span>Program Studi</span><strong><?= e($data['major_name']) ?></strong></div>
        <div><span>Fakultas/Sekolah</span><strong><?= e($data['faculty']) ?></strong></div>
        <div><span>Nomor HP</span><strong><?= e($data['phone']) ?></strong></div>
        <div><span>Asal Sekolah</span><strong><?= e($data['school']) ?></strong></div>
        <div><span>Tanggal Lahir</span><strong><?= e($data['birth_date']) ?></strong></div>
        <div><span>Jenis Kelamin</span><strong><?= e($data['gender']) ?></strong></div>
    </div>

    <div class="detail-text">
        <span>Alamat</span>
        <p><?= nl2br(e($data['address'])) ?></p>
    </div>

    <a class="btn primary" href="applicant_edit.php?id=<?= $id ?>">
        Edit Data
    </a>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
