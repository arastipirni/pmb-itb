<?php
/**
 * Kegunaan: Menampilkan pesan yang dikirim user melalui halaman Kontak.
 * Admin dapat membuka, menandai sudah dibaca, dan menghapus pesan.
 */
$pageTitle = 'Pesan dari User';
require_once __DIR__ . '/../includes/admin_header.php';

if (isset($_GET['read'])) {
    $messageId = (int) $_GET['read'];
    $stmt = $conn->prepare(
        'UPDATE contact_messages '
        . 'SET status = "read", read_at = NOW() '
        . 'WHERE id = ?'
    );
    $stmt->bind_param('i', $messageId);
    $stmt->execute();
    redirect('/pmb_itb/admin/messages.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $messageId = (int) $_POST['delete_id'];
    $stmt = $conn->prepare('DELETE FROM contact_messages WHERE id = ?');
    $stmt->bind_param('i', $messageId);
    $stmt->execute();
    flash('success', 'Pesan berhasil dihapus.');
    redirect('/pmb_itb/admin/messages.php');
}

$messages = [];
$result = $conn->query(
    'SELECT cm.*, u.name AS account_name '
    . 'FROM contact_messages cm '
    . 'LEFT JOIN users u ON cm.user_id = u.id '
    . 'ORDER BY cm.created_at DESC'
);

while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

$unreadCount = $conn->query(
    'SELECT COUNT(*) AS total FROM contact_messages WHERE status = "unread"'
)->fetch_assoc()['total'];
?>

<div class="admin-toolbar-row">
    <div>
        <span class="eyebrow">Pesan Masuk</span>
    </div>
    <div class="message-count-card">
        <span>Belum dibaca</span>
        <strong><?= e($unreadCount) ?></strong>
    </div>
</div>

<section class="admin-panel messages-panel">
    <?php if (!$messages): ?>
        <div class="empty-state">
            <div class="empty-icon">✉</div>
            <h3>Belum ada pesan</h3>
            <p>Pesan user yang dikirim melalui halaman Kontak akan muncul di sini.</p>
        </div>
    <?php else: ?>
        <div class="message-list">
            <?php foreach ($messages as $message): ?>
                <article class="message-card <?= $message['status'] === 'unread' ? 'is-unread' : '' ?>">
                    <div class="message-card-head">
                        <div>
                            <span class="message-status <?= $message['status'] === 'unread' ? 'unread' : 'read' ?>">
                                <?= $message['status'] === 'unread' ? 'Belum dibaca' : 'Sudah dibaca' ?>
                            </span>
                            <h3><?= e($message['subject']) ?></h3>
                        </div>
                        <time datetime="<?= e($message['created_at']) ?>">
                            <?= e(date('d/m/Y H:i', strtotime($message['created_at']))) ?>
                        </time>
                    </div>

                    <div class="message-meta">
                        <span><strong>Nama:</strong> <?= e($message['name']) ?></span>
                        <span><strong>Email:</strong> <?= e($message['email']) ?></span>
                        <?php if ($message['account_name']): ?>
                            <span><strong>Akun:</strong> <?= e($message['account_name']) ?></span>
                        <?php else: ?>
                            <span><strong>Sumber:</strong> Pengunjung</span>
                        <?php endif; ?>
                    </div>

                    <p class="message-body">
                        <?= nl2br(e($message['message'])) ?>
                    </p>

                    <div class="actions message-actions">
                        <?php if ($message['status'] === 'unread'): ?>
                            <a
                                class="action-btn detail-btn"
                                href="?read=<?= e($message['id']) ?>"
                            >
                                Tandai Dibaca
                            </a>
                        <?php endif; ?>

                        <form method="post" onsubmit="return confirm('Hapus pesan ini?');">
                            <input
                                type="hidden"
                                name="delete_id"
                                value="<?= e($message['id']) ?>"
                            >
                            <button class="action-btn delete-btn" type="submit">
                                Hapus
                            </button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
