<?php
/**
 * Kegunaan: Menghapus pengumuman.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare('DELETE FROM announcements WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();

flash('success', 'Pengumuman berhasil dihapus.');
redirect('/pmb_itb/admin/announcements.php');
?>
