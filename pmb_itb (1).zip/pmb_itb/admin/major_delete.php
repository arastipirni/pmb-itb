<?php
/**
 * Kegunaan: Menghapus program studi yang tidak digunakan lagi.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare('DELETE FROM majors WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();

flash('success', 'Jurusan berhasil dihapus.');
redirect('/pmb_itb/admin/majors.php');
?>
