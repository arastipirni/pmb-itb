<?php
/**
 * Kegunaan: Mengelola pengajuan daftar ulang dan penerbitan NIM.
 */

$pageTitle = 'Daftar Ulang';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? 'submitted';

    $stmt = $conn->prepare(
        'SELECT r.application_id, a.user_id '
        . 'FROM re_registrations r '
        . 'JOIN applications a ON a.id = r.application_id '
        . 'WHERE r.id = ? LIMIT 1'
    );
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();

    if ($item) {
        $nim = null;

        if ($status === 'approved') {
            $nim = generate_nim($conn);
        }

        $stmt = $conn->prepare(
            'UPDATE re_registrations SET status = ?, approved_at = '
            . 'IF(? = "approved", NOW(), approved_at) WHERE id = ?'
        );
        $stmt->bind_param('ssi', $status, $status, $id);
        $stmt->execute();

        if ($nim) {
            $stmt = $conn->prepare(
                'UPDATE applications SET status = "accepted", nim = ? '
                . 'WHERE id = ?'
            );
            $applicationId = (int) $item['application_id'];
            $stmt->bind_param('si', $nim, $applicationId);
            $stmt->execute();
        }

        flash('success', 'Status daftar ulang berhasil diperbarui.');
        redirect('/pmb_itb/admin/registrations.php');
    }
}

$rows = $conn->query(
    'SELECT r.id, r.status, r.payment_note, r.submitted_at, r.approved_at, '
    . 'u.name, u.email, a.test_number, a.nim, m.name AS major_name '
    . 'FROM re_registrations r '
    . 'JOIN applications a ON a.id = r.application_id '
    . 'JOIN users u ON u.id = a.user_id '
    . 'LEFT JOIN majors m ON m.id = a.major_id '
    . 'ORDER BY r.submitted_at DESC'
);
?>

<section class="admin-panel">
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Nomor Tes</th>
                    <th>Jurusan</th>
                    <th>Catatan</th>
                    <th>Status</th>
                    <th>NIM</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $rows->fetch_assoc()): ?>
                    <tr>
                        <td><?= e($row['name']) ?></td>
                        <td><?= e($row['email']) ?></td>
                        <td><?= e($row['test_number']) ?></td>
                        <td><?= e($row['major_name']) ?></td>
                        <td><?= e($row['payment_note']) ?></td>
                        <td><?= e($row['status']) ?></td>
                        <td><?= e($row['nim']) ?></td>
                        <td>
                            <?php if ($row['status'] === 'submitted'): ?>
                                <form method="post">
                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= $row['id'] ?>"
                                    >
                                    <input
                                        type="hidden"
                                        name="status"
                                        value="approved"
                                    >
                                    <button class="btn small" type="submit">
                                        Approve + NIM
                                    </button>
                                </form>
                            <?php else: ?>
                                Selesai
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
