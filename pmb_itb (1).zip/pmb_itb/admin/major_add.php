<?php
/**
 * Kegunaan: Menambahkan program studi ke database.
 */

$pageTitle = 'Tambah Jurusan';
require_once __DIR__ . '/../includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['code'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $faculty = trim($_POST['faculty'] ?? '');

    $stmt = $conn->prepare(
        'INSERT INTO majors (code, name, faculty) VALUES (?, ?, ?)'
    );
    $stmt->bind_param('sss', $code, $name, $faculty);
    $stmt->execute();

    flash('success', 'Jurusan berhasil ditambahkan.');
    redirect('/pmb_itb/admin/majors.php');
}
?>

<section class="admin-panel narrow-admin-panel">
    <form method="post" class="form-stack">
        <label>
            Kode
            <input type="text" name="code" required>
        </label>

        <label>
            Program Studi
            <input type="text" name="name" required>
        </label>

        <label>
            Fakultas / Sekolah
            <input type="text" name="faculty" required>
        </label>

        <button class="btn primary" type="submit">
            Simpan Jurusan
        </button>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
