<?php
/**
 * Kegunaan: Mengubah isi soal dan kunci jawaban.
 */

$pageTitle = 'Edit Soal';
require_once __DIR__ . '/../includes/admin_header.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = $conn->prepare('SELECT * FROM questions WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    flash('error', 'Soal tidak ditemukan.');
    redirect('/pmb_itb/admin/questions.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = trim($_POST['question'] ?? '');
    $a = trim($_POST['option_a'] ?? '');
    $b = trim($_POST['option_b'] ?? '');
    $c = trim($_POST['option_c'] ?? '');
    $d = trim($_POST['option_d'] ?? '');
    $correct = $_POST['correct_answer'] ?? 'a';
    $active = isset($_POST['is_active']) ? 1 : 0;

    $stmt = $conn->prepare(
        'UPDATE questions SET question = ?, option_a = ?, option_b = ?, '
        . 'option_c = ?, option_d = ?, correct_answer = ?, is_active = ? '
        . 'WHERE id = ?'
    );

    $stmt->bind_param(
        'ssssssii',
        $question,
        $a,
        $b,
        $c,
        $d,
        $correct,
        $active,
        $id
    );

    $stmt->execute();
    flash('success', 'Soal berhasil diperbarui.');
    redirect('/pmb_itb/admin/questions.php');
}
?>

<section class="admin-panel narrow-admin-panel">
    <form method="post" class="form-stack">
        <label>
            Pertanyaan
            <textarea name="question" rows="5" required><?= e(
                $data['question']
            ) ?></textarea>
        </label>

        <label>
            Pilihan A
            <input
                type="text"
                name="option_a"
                value="<?= e($data['option_a']) ?>"
                required
            >
        </label>

        <label>
            Pilihan B
            <input
                type="text"
                name="option_b"
                value="<?= e($data['option_b']) ?>"
                required
            >
        </label>

        <label>
            Pilihan C
            <input
                type="text"
                name="option_c"
                value="<?= e($data['option_c']) ?>"
                required
            >
        </label>

        <label>
            Pilihan D
            <input
                type="text"
                name="option_d"
                value="<?= e($data['option_d']) ?>"
                required
            >
        </label>

        <label>
            Kunci Jawaban
            <select name="correct_answer">
                <?php foreach (['a', 'b', 'c', 'd'] as $key): ?>
                    <option
                        value="<?= $key ?>"
                        <?= $data['correct_answer'] === $key ?
                            'selected' : '' ?>
                    >
                        <?= strtoupper($key) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <label class="check-row">
            <input
                type="checkbox"
                name="is_active"
                <?= $data['is_active'] ? 'checked' : '' ?>
            >
            Aktifkan soal
        </label>

        <button class="btn primary" type="submit">
            Simpan Perubahan
        </button>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
