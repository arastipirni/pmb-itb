<?php
/**
 * Kegunaan: Membuat akun baru untuk calon mahasiswa.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($password !== $confirm) {
        $error = 'Konfirmasi password tidak sama.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } else {
        $stmt = $conn->prepare(
            'SELECT id FROM users WHERE email = ? LIMIT 1'
        );
        $stmt->bind_param('s', $email);
        $stmt->execute();

        if ($stmt->get_result()->fetch_assoc()) {
            $error = 'Email sudah terdaftar.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare(
                'INSERT INTO users (name, email, password, role) '
                . 'VALUES (?, ?, ?, "user")'
            );

            $stmt->bind_param('sss', $name, $email, $hash);
            $stmt->execute();

            $userId = $conn->insert_id;

            $stmt = $conn->prepare(
                'INSERT INTO applications (user_id, status) '
                . 'VALUES (?, "registered")'
            );

            $stmt->bind_param('i', $userId);
            $stmt->execute();

            flash('success', 'Registrasi berhasil. Silakan login.');
            redirect('/pmb_itb/auth/login.php');
        }
    }
}

$pageTitle = 'Registrasi User';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="auth-layout">
    <div class="auth-card wide">
        <span class="eyebrow">Pendaftaran Akun</span>
        <h1>Registrasi Calon Mahasiswa</h1>
        <p>
            Buat akun terlebih dahulu sebelum melanjutkan pendaftaran.
        </p>

        <?php if ($error): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" class="form-grid two">
            <label>
                Nama Lengkap
                <input
                    type="text"
                    name="name"
                    required
                >
            </label>

            <label>
                Email
                <input
                    type="email"
                    name="email"
                    required
                >
            </label>

            <label>
                Password
                <input
                    type="password"
                    name="password"
                    required
                >
            </label>

            <label>
                Konfirmasi Password
                <input
                    type="password"
                    name="confirm_password"
                    required
                >
            </label>

            <div class="full-width">
                <button class="btn primary" type="submit">
                    Buat Akun
                </button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
