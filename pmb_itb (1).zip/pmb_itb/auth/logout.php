<?php
/**
 * Kegunaan: Mengeluarkan user dari sesi login.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/auth.php';

logout_user();

header('Location: /pmb_itb/index.php');
exit;
?>
