<?php
/**
 * Kegunaan: Memproses login calon mahasiswa/user.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/auth.php';

if (is_logged_in() && !is_admin()) {
    redirect('/pmb_itb/user/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare(
        'SELECT id, name, email, password, role '
        . 'FROM users WHERE email = ? AND role = "user" LIMIT 1'
    );

    $stmt->bind_param('s', $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        login_user($user);
        log_activity($conn, $user['id'], 'Login user');
        redirect('/pmb_itb/user/dashboard.php');
    }

    $error = 'Email atau password tidak sesuai.';
}

$pageTitle = 'Login User';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="auth-layout">
    <div class="auth-card">
        <span class="eyebrow">Calon Mahasiswa</span>
        <h1>Login User</h1>
        <p>
            Masuk untuk melanjutkan proses pendaftaran PMB.
        </p>

        <?php if ($error): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" class="form-stack">
            <label>
                Email
                <input
                    type="email"
                    name="email"
                    required
                >
            </label>

            <label>
                Password
                <input
                    type="password"
                    name="password"
                    required
                >
            </label>

            <button class="btn primary" type="submit">
                Login
            </button>
        </form>

        <p class="form-note">
            Belum punya akun?
            <a href="<?= $baseUrl ?>/auth/register.php">Daftar di sini</a>
        </p>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
