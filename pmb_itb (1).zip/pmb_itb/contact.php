<?php
/**
 * Kegunaan: Menampilkan halaman Kontak dan menerima pesan dari pendaftar.
 * Halaman ini dapat diakses oleh pengunjung maupun user yang sudah login.
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/helpers.php';

$name = is_logged_in() && !is_admin() ? ($_SESSION['name'] ?? '') : '';
$email = is_logged_in() && !is_admin() ? ($_SESSION['email'] ?? '') : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '' || $email === '' || $subject === '' || $message === '') {
        flash('error', 'Semua kolom kontak wajib diisi.');
        redirect('/pmb_itb/contact.php');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('error', 'Format email belum benar.');
        redirect('/pmb_itb/contact.php');
    }

    $userId = (is_logged_in() && !is_admin())
        ? (int) $_SESSION['user_id']
        : null;

    $stmt = $conn->prepare(
        'INSERT INTO contact_messages '
        . '(user_id, name, email, subject, message, status) '
        . 'VALUES (?, ?, ?, ?, ?, "unread")'
    );

    $stmt->bind_param(
        'issss',
        $userId,
        $name,
        $email,
        $subject,
        $message
    );
    $stmt->execute();

    flash(
        'success',
        'Pesan berhasil dikirim. Admin akan memeriksa pesan kamu.'
    );
    redirect('/pmb_itb/contact.php');
}

$pageTitle = 'Kontak PMB ITB';
require_once __DIR__ . '/includes/header.php';
?>

<section class="contact-hero">
    <div>
        <span class="eyebrow">Kontak</span>
        <h1>Membutuhkan Bantuan dalam Proses PMB?</h1>
        <p>
            Sampaikan pertanyaan, kendala teknis, atau informasi yang ingin Anda
            tanyakan terkait proses Penerimaan Mahasiswa Baru. Pesan yang Anda 
            kirim akan diterima oleh pihak pengelola untuk ditindaklanjuti.
        </p>
    </div>
    <div class="contact-hero-card">
        <div class="contact-icon">✉</div>
        <strong>Layanan bantuan</strong>
        <span>Senin–Jumat, 08.00–16.00 WIB</span>
        <span>Email: InstitutTeknologiBandung@gmail.com</span>
    </div>
</section>

<section class="contact-layout section-block">
    <div class="contact-info-grid">
        <article class="contact-info-card">
            <span class="contact-info-icon">✉</span>
            <h2>Email</h2>
            <strong>InstitutTeknologiBandung@gmail.com</strong>
        </article>

        <article class="contact-info-card">
            <span class="contact-info-icon">◷</span>
            <h2>Jam Layanan</h2>
            <strong>Senin–Jumat, 08.00–16.00 WIB</strong>
        </article>

        <article class="contact-info-card">
            <span class="contact-info-icon">?</span>
            <h2>Bantuan PMB</h2>
            <strong>Registrasi • Tes • Daftar Ulang</strong>
        </article>
    </div>

    <div class="contact-form-card">
        <div class="section-heading contact-heading">
            <span class="eyebrow">Kirim Pesan</span>
            <h2>Hubungi Admin PMB</h2>
            <p>
                Isi formulir berikut. Untuk user yang sudah login, nama dan
                email akan terisi otomatis.
            </p>
        </div>

        <form method="post" class="form-grid">
            <div class="form-group">
                <label for="name">Nama Lengkap</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value="<?= e($name) ?>"
                    maxlength="120"
                    required
                >
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?= e($email) ?>"
                    maxlength="150"
                    required
                >
            </div>

            <div class="form-group full-width">
                <label for="subject">Subjek Pesan</label>
                <input
                    type="text"
                    id="subject"
                    name="subject"
                    maxlength="180"
                    placeholder="Contoh: Kendala login, kartu ujian, atau tes"
                    required
                >
            </div>

            <div class="form-group full-width">
                <label for="message">Pesan</label>
                <textarea
                    id="message"
                    name="message"
                    rows="7"
                    maxlength="2000"
                    placeholder="Tuliskan pertanyaan atau kendala kamu secara jelas..."
                    required
                ></textarea>
            </div>

            <div class="form-actions full-width">
                <a class="btn ghost" href="<?= $baseUrl ?>/index.php">
                    Kembali
                </a>
                <button class="btn primary" type="submit">
                    Kirim Pesan
                </button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
