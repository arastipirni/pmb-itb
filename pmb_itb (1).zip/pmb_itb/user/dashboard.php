<?php
/**
 * Kegunaan: Dashboard calon mahasiswa setelah login.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

ensure_application($conn, $_SESSION['user_id']);

$stmt = $conn->prepare(
    'SELECT a.*, m.name AS major_name, m.faculty '
    . 'FROM applications a '
    . 'LEFT JOIN majors m ON a.major_id = m.id '
    . 'WHERE a.user_id = ? LIMIT 1'
);

$userId = $_SESSION['user_id'];
$stmt->bind_param('i', $userId);
$stmt->execute();
$application = $stmt->get_result()->fetch_assoc();

$pageTitle = 'Dashboard User';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="dashboard-head">
    <div>
        <span class="eyebrow">Dashboard</span>
        <h1>Selamat Datang, <?= e($_SESSION['name']) ?> </h1>
        <p>
            Pantau status pendaftaran, tahapan seleksi, dan informasi penerimaan Anda melalui halaman ini.
        </p>
    </div>

    <div class="status-panel">
        <span>Status pendaftaran</span>
        <strong><?= e(status_badge($application['status'])) ?></strong>
    </div>
</div>

<section class="nim-highlight">
    <div class="nim-icon">NIM</div>
    <div class="nim-content">
        <span class="eyebrow">Nomor Induk Mahasiswa</span>
        <h2><?= e($application['nim'] ?: 'Belum Diterbitkan') ?></h2>
    </div>
    <?php if ($application['nim']): ?>
        <a class="btn primary" href="card.php">Lihat Kartu</a>
    <?php endif; ?>
</section>

<div class="card-grid four">
    <a class="feature-card link-card" href="profile.php">
        <h3>1. Profil</h3>
        <p>Lengkapi identitas dan pilihan jurusan.</p>
    </a>

    <a class="feature-card link-card" href="exam-card.php">
        <h3>2. Kartu Ujian</h3>
        <p>Lihat dan cetak kartu ujian dari nomor tes kamu.</p>
    </a>

    <a class="feature-card link-card" href="test.php">
        <h3>3. Tes</h3>
        <p>Kerjakan soal seleksi dengan timer yang tersedia.</p>
    </a>

    <a class="feature-card link-card" href="result.php">
        <h3>4. Hasil</h3>
        <p>Lihat status kelulusan setelah tes selesai.</p>
    </a>

    <a class="feature-card link-card" href="re-registration.php">
        <h3>5. Daftar Ulang</h3>
        <p>Lakukan daftar ulang jika dinyatakan lulus.</p>
    </a>
</div>

<section class="panel">
    <div class="panel-heading">
        <h2>Informasi Pendaftaran</h2>
    </div>

    <div class="data-grid two">
        <div>
            <span>Nomor Tes</span>
            <strong>
                <?= e($application['test_number'] ?: 'Belum tersedia') ?>
            </strong>
        </div>

        <div>
            <span>Jurusan</span>
            <strong>
                <?= e($application['major_name'] ?: 'Belum dipilih') ?>
            </strong>
        </div>

        <div>
            <span>Fakultas/Sekolah</span>
            <strong>
                <?= e($application['faculty'] ?: 'Belum tersedia') ?>
            </strong>
        </div>

        <div>
            <span>NIM</span>
            <strong>
                <?= e($application['nim'] ?: 'Belum tersedia') ?>
            </strong>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
