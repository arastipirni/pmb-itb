<?php
/**
 * Kegunaan: Mengelola proses daftar ulang calon mahasiswa yang lulus tes.
 * Pengajuan disimpan ke database dan menunggu persetujuan admin.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

$userId = (int) $_SESSION['user_id'];
ensure_application($conn, $userId);

$stmt = $conn->prepare(
    'SELECT a.*, r.id AS re_reg_id, r.status AS re_reg_status, '
    . 'r.payment_note, r.submitted_at, r.approved_at, '
    . 'm.name AS major_name, m.faculty '
    . 'FROM applications a '
    . 'LEFT JOIN re_registrations r ON r.application_id = a.id '
    . 'LEFT JOIN majors m ON m.id = a.major_id '
    . 'WHERE a.user_id = ? LIMIT 1'
);
$stmt->bind_param('i', $userId);
$stmt->execute();
$application = $stmt->get_result()->fetch_assoc();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($application['status'] !== 'passed') {
        $error = 'Daftar ulang hanya dapat diajukan setelah status tes kamu adalah Lulus.';
    } elseif ($application['re_reg_id']) {
        $error = 'Pengajuan daftar ulang sudah pernah dikirim.';
    } else {
        $confirmed = isset($_POST['confirm_rereg'])
            && $_POST['confirm_rereg'] === 'yes';

        if (!$confirmed) {
            $error = 'Centang persetujuan daftar ulang sebelum mengirim konfirmasi.';
        } else {
            $note = 'Saya menyatakan siap mengikuti proses daftar ulang dan melengkapi dokumen yang dipersyaratkan.';
            $applicationId = (int) $application['id'];

            $stmt = $conn->prepare(
                'INSERT INTO re_registrations '
                . '(application_id, payment_note, status) '
                . 'VALUES (?, ?, "submitted")'
            );
            $stmt->bind_param('is', $applicationId, $note);
            $stmt->execute();

            $stmt = $conn->prepare(
                'UPDATE applications SET status = "re_registered" '
                . 'WHERE id = ?'
            );
            $stmt->bind_param('i', $applicationId);
            $stmt->execute();

            flash('success', 'Daftar ulang berhasil dikirim dan menunggu persetujuan admin.');
            redirect('/pmb_itb/user/re-registration.php');
        }
    }
}

$pageTitle = 'Daftar Ulang';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="section-block narrow">
    <div class="section-heading">
        <span class="eyebrow">Tahap 08 · Daftar Ulang</span>
        <h1>Daftar Ulang Calon Mahasiswa</h1>
        <p>
            Ajukan konfirmasi daftar ulang setelah kamu dinyatakan lulus.
            Setelah dikirim, admin akan memeriksa dan menerbitkan NIM.
        </p>
    </div>

    <?php if ($error): ?>
        <div class="alert error"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($application['status'] !== 'passed' && !$application['re_reg_id']): ?>
        <div class="panel">
            <h2>Daftar Ulang Belum Aktif</h2>
            <p>
                Status pendaftaran saat ini:
                <strong><?= e(status_badge($application['status'])) ?></strong>.
            </p>
            <p>
                Kamu harus menyelesaikan tes dan memperoleh status
                <strong>Lulus</strong> terlebih dahulu.
            </p>
            <div class="form-actions">
                <a class="btn secondary" href="result.php">Lihat Hasil Tes</a>
                <a class="btn primary" href="dashboard.php">Kembali ke Dashboard</a>
            </div>
        </div>
    <?php elseif ($application['re_reg_id']): ?>
        <div class="panel">
            <div class="status-panel">
                <span>Status daftar ulang</span>
                <strong><?= e(ucfirst($application['re_reg_status'])) ?></strong>
            </div>

            <div class="data-grid two" style="margin-top: 22px;">
                <div>
                    <span>Nomor Tes</span>
                    <strong><?= e($application['test_number']) ?></strong>
                </div>
                <div>
                    <span>Program Studi</span>
                    <strong><?= e($application['major_name'] ?: '-') ?></strong>
                </div>
                <div>
                    <span>Catatan Konfirmasi</span>
                    <strong><?= e($application['payment_note'] ?: '-') ?></strong>
                </div>
                <div>
                    <span>NIM</span>
                    <strong><?= e($application['nim'] ?: 'Menunggu persetujuan admin') ?></strong>
                </div>
            </div>

            <?php if ($application['nim']): ?>
                <div class="form-actions" style="margin-top: 22px;">
                    <a class="btn primary" href="card.php">Lihat Kartu Mahasiswa</a>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="panel">
            <div class="status-panel">
                <span>Status kelulusan</span>
                <strong>Lulus</strong>
            </div>

            <div class="data-grid two" style="margin: 22px 0;">
                <div>
                    <span>Nama</span>
                    <strong><?= e($_SESSION['name']) ?></strong>
                </div>
                <div>
                    <span>Nomor Tes</span>
                    <strong><?= e($application['test_number']) ?></strong>
                </div>
            </div>

            <form method="post" class="form-stack">
                <h3 class="agreement-title">Konfirmasi Daftar Ulang</h3>
                <label class="agreement-checkbox">
                    <input
                        type="checkbox"
                        name="confirm_rereg"
                        value="yes"
                        required
                    >
                    <span>
                        Saya menyatakan siap mengikuti proses daftar ulang dan
                        melengkapi dokumen yang dipersyaratkan.
                    </span>
                </label>

                <button class="btn primary" type="submit">
                    Kirim Daftar Ulang
                </button>
            </form>
        </div>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
