<?php
/**
 * Kegunaan: Menampilkan hasil tes terakhir calon mahasiswa.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

ensure_application($conn, $_SESSION['user_id']);

$stmt = $conn->prepare(
    'SELECT a.*, m.name AS major_name '
    . 'FROM applications a '
    . 'LEFT JOIN majors m ON a.major_id = m.id '
    . 'WHERE a.user_id = ? LIMIT 1'
);
$userId = $_SESSION['user_id'];
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

$pageTitle = 'Hasil Tes';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="result-layout">
    <div class="result-card">
        <span class="eyebrow">Hasil Seleksi</span>
        <h1><?= e(status_badge($result['status'])) ?></h1>
        <div class="result-info">
            <div>
                <span>Nomor Tes</span>
                <strong><?= e($result['test_number']) ?></strong>
            </div>
            <div>
                <span>Program Studi</span>
                <strong><?= e($result['major_name']) ?></strong>
            </div>
            <div>
                <span>NIM</span>
                <strong><?= e($result['nim'] ?: 'Belum diterbitkan') ?></strong>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
