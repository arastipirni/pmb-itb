<?php
/**
 * Kegunaan: Menyimpan dan memperbarui profil calon mahasiswa.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

ensure_application($conn, $_SESSION['user_id']);

$error = '';

$stmt = $conn->prepare(
    'SELECT u.name, u.email, a.*, a.major_id '
    . 'FROM users u '
    . 'JOIN applications a ON a.user_id = u.id '
    . 'WHERE u.id = ? LIMIT 1'
);

$userId = $_SESSION['user_id'];
$stmt->bind_param('i', $userId);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $birthDate = $_POST['birth_date'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $address = trim($_POST['address'] ?? '');
    $school = trim($_POST['school'] ?? '');
    $majorId = (int) ($_POST['major_id'] ?? 0);

    if ($name === '' || $majorId === 0) {
        $error = 'Nama dan jurusan wajib diisi.';
    } else {
        $stmt = $conn->prepare(
            'UPDATE users SET name = ? WHERE id = ?'
        );
        $userId = $_SESSION['user_id'];
        $stmt->bind_param('si', $name, $userId);
        $stmt->execute();

        $stmt = $conn->prepare(
            'UPDATE applications SET '
            . 'phone = ?, birth_date = ?, gender = ?, address = ?, '
            . 'school = ?, major_id = ?, updated_at = NOW() '
            . 'WHERE user_id = ?'
        );

        $currentUserId = (int) $_SESSION['user_id'];

        $stmt->bind_param(
            'sssssii',
            $phone,
            $birthDate,
            $gender,
            $address,
            $school,
            $majorId,
            $currentUserId
        );

        $stmt->execute();

        if (!$profile['test_number']) {
            $testNumber = generate_test_number($conn);

            $stmt = $conn->prepare(
                'UPDATE applications SET test_number = ? '
                . 'WHERE user_id = ?'
            );
            $currentUserId = (int) $_SESSION['user_id'];

            $stmt->bind_param(
                'si',
                $testNumber,
                $currentUserId
            );
            $stmt->execute();
        }

        $_SESSION['name'] = $name;
        flash('success', 'Profil berhasil diperbarui.');
        redirect('/pmb_itb/user/profile.php');
    }
}

$majors = $conn->query(
    'SELECT id, name, faculty FROM majors ORDER BY faculty, name'
);

$pageTitle = 'Profil Calon Mahasiswa';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="section-block">
    <div class="section-heading">
        <span class="eyebrow">Profil</span>
        <h1>Data Calon Mahasiswa</h1>
        <p>
            Lengkapi data berikut agar nomor tes dapat dibuat.
        </p>
    </div>

    <?php if ($error): ?>
        <div class="alert error"><?= e($error) ?></div>
    <?php endif; ?>

    <div class="profile-status-grid">
        <div class="profile-status-card">
            <span>Nomor Tes</span>
            <strong><?= e($profile['test_number'] ?: 'Belum tersedia') ?></strong>
        </div>
        <div class="profile-status-card nim-mini">
            <span>NIM</span>
            <strong><?= e($profile['nim'] ?: 'Belum diterbitkan') ?></strong>
        </div>
        <div class="profile-status-card">
            <span>Status</span>
            <strong><?= e(status_badge($profile['status'])) ?></strong>
        </div>
    </div>

    <div class="panel">
        <form method="post" class="form-grid two">
            <label>
                Nama Lengkap
                <input
                    type="text"
                    name="name"
                    value="<?= e($profile['name']) ?>"
                    required
                >
            </label>

            <label>
                Email
                <input
                    type="email"
                    value="<?= e($profile['email']) ?>"
                    disabled
                >
            </label>

            <label>
                Nomor HP
                <input
                    type="text"
                    name="phone"
                    value="<?= e($profile['phone']) ?>"
                >
            </label>

            <label>
                Tanggal Lahir
                <input
                    type="date"
                    name="birth_date"
                    value="<?= e($profile['birth_date']) ?>"
                >
            </label>

            <label>
                Jenis Kelamin
                <select name="gender">
                    <option value="">Pilih</option>
                    <option
                        value="L"
                        <?= $profile['gender'] === 'L' ? 'selected' : '' ?>
                    >
                        Laki-laki
                    </option>
                    <option
                        value="P"
                        <?= $profile['gender'] === 'P' ? 'selected' : '' ?>
                    >
                        Perempuan
                    </option>
                </select>
            </label>

            <label>
                Asal Sekolah
                <input
                    type="text"
                    name="school"
                    value="<?= e($profile['school']) ?>"
                >
            </label>

            <label class="full-width">
                Alamat
                <textarea name="address" rows="4"><?= e(
                    $profile['address']
                ) ?></textarea>
            </label>

            <label class="full-width">
                Pilihan Program Studi
                <select name="major_id" required>
                    <option value="">Pilih program studi</option>

                    <?php
                    $currentFaculty = '';
                    while ($major = $majors->fetch_assoc()):
                    ?>
                        <?php if ($currentFaculty !== $major['faculty']): ?>
                            <?php if ($currentFaculty !== ''): ?>
                                </optgroup>
                            <?php endif; ?>

                            <optgroup
                                label="<?= e($major['faculty']) ?>"
                            >
                            <?php
                            $currentFaculty = $major['faculty'];
                            ?>
                        <?php endif; ?>

                        <option
                            value="<?= (int) $major['id'] ?>"
                            <?= (int) $profile['major_id'] ===
                                (int) $major['id'] ? 'selected' : '' ?>
                        >
                            <?= e($major['name']) ?>
                        </option>
                    <?php endwhile; ?>

                    <?php if ($currentFaculty !== ''): ?>
                        </optgroup>
                    <?php endif; ?>
                </select>
            </label>

            <div class="full-width">
                <button class="btn primary" type="submit">
                    Simpan Profil
                </button>
            </div>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
