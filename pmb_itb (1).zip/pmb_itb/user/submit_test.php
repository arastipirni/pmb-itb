<?php
/**
 * Kegunaan: Memeriksa jawaban tes, menghitung skor untuk penilaian internal,
 * dan menyimpan hasil seleksi tanpa menampilkan skor kepada peserta.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/auth.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/pmb_itb/user/test.php');
}

$userId = (int) $_SESSION['user_id'];
$stmt = $conn->prepare(
    'SELECT id, status FROM applications WHERE user_id = ? LIMIT 1'
);
$stmt->bind_param('i', $userId);
$stmt->execute();
$application = $stmt->get_result()->fetch_assoc();

if (
    !$application
    || (int) ($_SESSION['test_access_application_id'] ?? 0) !== (int) $application['id']
    || $application['status'] !== 'registered'
) {
    unset($_SESSION['test_access_application_id']);
    flash('error', 'Verifikasi nomor tes diperlukan sebelum mengerjakan ujian.');
    redirect('/pmb_itb/user/test.php');
}

$answers = $_POST['answers'] ?? [];
if (!is_array($answers) || !$answers) {
    flash('error', 'Jawaban belum dikirim. Silakan periksa soal dan coba lagi.');
    redirect('/pmb_itb/user/test.php');
}

$total = 0;
$correct = 0;
$applicationId = (int) $application['id'];

$questions = $conn->query(
    'SELECT id, correct_answer FROM questions '
    . 'WHERE is_active = 1 ORDER BY id'
);

$answerStmt = $conn->prepare(
    'INSERT INTO test_answers '
    . '(attempt_id, question_id, selected_answer, is_correct) '
    . 'VALUES (?, ?, ?, ?)'
);

$conn->begin_transaction();

try {
    $stmt = $conn->prepare(
        'INSERT INTO test_attempts '
        . '(user_id, application_id, score, status) '
        . 'VALUES (?, ?, 0, "tested")'
    );
    $stmt->bind_param('ii', $userId, $applicationId);
    $stmt->execute();
    $attemptId = (int) $conn->insert_id;

    while ($question = $questions->fetch_assoc()) {
        $total++;
        $questionId = (int) $question['id'];
        $selected = strtolower(substr((string) ($answers[$questionId] ?? ''), 0, 1));
        if (!in_array($selected, ['a', 'b', 'c', 'd'], true)) {
            $selected = '';
        }
        $isCorrect = $selected === $question['correct_answer'] ? 1 : 0;

        if ($isCorrect) {
            $correct++;
        }

        $answerStmt->bind_param(
            'iisi',
            $attemptId,
            $questionId,
            $selected,
            $isCorrect
        );
        $answerStmt->execute();
    }

    $score = $total > 0 ? (int) round(($correct / $total) * 100) : 0;
    $status = $score >= 70 ? 'passed' : 'failed';

    $stmt = $conn->prepare(
        'UPDATE test_attempts SET score = ?, status = ? WHERE id = ?'
    );
    $stmt->bind_param('isi', $score, $status, $attemptId);
    $stmt->execute();

    $stmt = $conn->prepare(
        'UPDATE applications SET status = ?, test_score = ?, test_date = NOW() WHERE id = ?'
    );
    $stmt->bind_param('sii', $status, $score, $applicationId);
    $stmt->execute();

    log_activity($conn, $userId, 'Mengikuti tes PMB');
    $conn->commit();
    unset($_SESSION['test_access_application_id']);

    flash('success', 'Tes selesai. Hasil seleksi berhasil disimpan.');
    redirect('/pmb_itb/user/result.php');
} catch (Throwable $e) {
    $conn->rollback();
    flash('error', 'Terjadi kesalahan saat menyimpan tes. Silakan coba kembali.');
    redirect('/pmb_itb/user/test.php');
}
?>
