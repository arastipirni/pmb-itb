<?php
/**
 * Kegunaan: Menampilkan kartu ujian berdasarkan nomor tes calon mahasiswa.
 * Kartu dapat dicetak atau disimpan sebagai PDF melalui browser.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

ensure_application($conn, $_SESSION['user_id']);

$stmt = $conn->prepare(
    'SELECT u.name, u.email, a.test_number, a.school, '
    . 'a.birth_date, a.gender, m.name AS major_name, m.faculty '
    . 'FROM users u '
    . 'JOIN applications a ON a.user_id = u.id '
    . 'LEFT JOIN majors m ON a.major_id = m.id '
    . 'WHERE u.id = ? LIMIT 1'
);

$userId = $_SESSION['user_id'];
$stmt->bind_param('i', $userId);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data || !$data['test_number']) {
    flash('error', 'Lengkapi profil terlebih dahulu agar kartu ujian tersedia.');
    redirect('/pmb_itb/user/profile.php');
}

$pageTitle = 'Kartu Ujian PMB';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="section-block narrow">
    <div class="section-heading">
        <span class="eyebrow">Tahap Ujian</span>
        <h1>Kartu Ujian PMB</h1>
        <p>
            Simpan atau cetak kartu ini sebelum mengerjakan tes seleksi.
        </p>
    </div>

    <div class="exam-card">
        <div class="exam-card-top">
            <img
                src="<?= $baseUrl ?>/assets/images/itb-logo.png"
                alt="Logo Institut Teknologi Bandung"
            >
            <div>
                <strong>INSTITUT TEKNOLOGI BANDUNG</strong>
                <small>Kartu Ujian Seleksi Mahasiswa Baru</small>
            </div>
        </div>

        <div class="exam-card-body">
            <div class="exam-card-field">
                <span>Nomor Tes</span>
                <strong><?= e($data['test_number']) ?></strong>
            </div>

            <div class="exam-card-field">
                <span>Nama Peserta</span>
                <strong><?= e($data['name']) ?></strong>
            </div>

            <div class="exam-card-field">
                <span>Email</span>
                <strong><?= e($data['email']) ?></strong>
            </div>

            <div class="exam-card-field">
                <span>Asal Sekolah</span>
                <strong><?= e($data['school'] ?: '-') ?></strong>
            </div>

            <div class="exam-card-field">
                <span>Program Studi</span>
                <strong><?= e($data['major_name'] ?: '-') ?></strong>
            </div>

            <div class="exam-card-field">
                <span>Sekolah/Fakultas</span>
                <strong><?= e($data['faculty'] ?: '-') ?></strong>
            </div>
        </div>

        <div class="panel" style="margin: 0 26px 26px;">
            <strong>Petunjuk sebelum ujian</strong>
            <div class="data-grid" style="margin-top: 14px;">
                <div>
                    <span>01</span>
                    <strong>Pastikan nama dan nomor tes benar.</strong>
                </div>
                <div>
                    <span>02</span>
                    <strong>Gunakan perangkat dengan koneksi stabil.</strong>
                </div>
                <div>
                    <span>03</span>
                    <strong>Timer berjalan setelah halaman tes dibuka.</strong>
                </div>
            </div>
        </div>

        <button
            class="btn primary print-button"
            onclick="window.print()"
        >
            Cetak / Simpan PDF
        </button>

        <a
            class="btn secondary print-button"
            href="test.php"
        >
            Lanjut ke Tes
        </a>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
