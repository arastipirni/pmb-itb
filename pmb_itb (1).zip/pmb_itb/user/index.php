<?php
/**
 * Kegunaan: Pintu masuk singkat untuk area calon mahasiswa.
 * URL /pmb_itb/user akan diarahkan ke dashboard user.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';

if (!is_logged_in() || is_admin()) {
    redirect('/pmb_itb/auth/login.php');
}

redirect('/pmb_itb/user/dashboard.php');
