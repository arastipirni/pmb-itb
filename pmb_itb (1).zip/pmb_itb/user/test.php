<?php
/**
 * Kegunaan: Memverifikasi nomor tes peserta sebelum menampilkan soal pilihan ganda.
 * Timer tes dibuat 30 menit untuk simulasi project.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

ensure_application($conn, $_SESSION['user_id']);

$stmt = $conn->prepare(
    'SELECT id, test_number, status FROM applications WHERE user_id = ? LIMIT 1'
);
$userId = (int) $_SESSION['user_id'];
$stmt->bind_param('i', $userId);
$stmt->execute();
$application = $stmt->get_result()->fetch_assoc();

if (!$application || !$application['test_number']) {
    flash('error', 'Lengkapi profil terlebih dahulu agar nomor tes tersedia.');
    redirect('/pmb_itb/user/profile.php');
}

if (in_array(
    $application['status'],
    ['tested', 'passed', 'failed', 're_registered', 'accepted'],
    true
)) {
    flash('success', 'Tes kamu sudah pernah dikerjakan. Silakan lihat status hasil seleksi.');
    redirect('/pmb_itb/user/result.php');
}

$testEntryError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_test_number'])) {
    $enteredNumber = strtoupper(preg_replace('/\s+/', '', trim((string) ($_POST['test_number'] ?? ''))));
    $savedNumber = strtoupper(preg_replace('/\s+/', '', trim((string) $application['test_number'])));

    if ($enteredNumber !== '' && hash_equals($savedNumber, $enteredNumber)) {
        $_SESSION['test_access_application_id'] = (int) $application['id'];
        redirect('/pmb_itb/user/test.php');
    }

    $testEntryError = 'Nomor tes tidak sesuai. Periksa kembali nomor pada kartu ujian kamu.';
}

$accessGranted = isset($_SESSION['test_access_application_id'])
    && (int) $_SESSION['test_access_application_id'] === (int) $application['id'];

if ($accessGranted) {
    $questions = $conn->query(
        'SELECT id, question, option_a, option_b, option_c, option_d '
        . 'FROM questions WHERE is_active = 1 ORDER BY id'
    );
    $totalQuestions = $questions ? $questions->num_rows : 0;
} else {
    $totalQuestions = 0;
}

$pageTitle = $accessGranted ? 'Tes Seleksi PMB' : 'Verifikasi Nomor Tes';
require_once __DIR__ . '/../includes/header.php';
?>

<?php if (!$accessGranted): ?>
    <section class="test-layout test-entry-layout">
        <div class="test-entry-card panel">
            <span class="eyebrow">Verifikasi Peserta</span>
            <h1>Masukkan Nomor Tes</h1>
            <p>
                Ketik nomor tes yang tertera pada kartu ujian. Soal seleksi
                hanya akan terbuka setelah nomor tes kamu cocok dengan data pendaftaran.
            </p>

            <?php if ($testEntryError): ?>
                <div class="alert error"><?= e($testEntryError) ?></div>
            <?php endif; ?>

            <form method="post" action="test.php" class="form-stack">
                <label>
                    Nomor Tes Peserta
                    <input
                        type="text"
                        name="test_number"
                        placeholder="Contoh: ITB-TEST-2026-00004"
                        autocomplete="off"
                        autocapitalize="characters"
                        spellcheck="false"
                        required
                    >
                </label>
                <button class="btn primary" type="submit" name="verify_test_number" value="1">
                    Verifikasi dan Mulai Ujian
                </button>
            </form>
            <p class="form-note">
                Belum tahu nomor tes kamu? Periksa kembali halaman Profil atau Kartu Ujian.
            </p>
        </div>
    </section>
<?php else: ?>
    <section class="test-layout">
        <div class="test-head">
            <div>
                <span class="eyebrow">Tes Seleksi • <?= (int) $totalQuestions ?> Soal</span>
                <h1>Nomor Tes: <?= e($application['test_number']) ?></h1>
                <p class="test-intro">
                    Jawab seluruh soal dengan teliti. Tes akan dikirim otomatis saat waktu habis.
                </p>
            </div>

            <div
                class="timer-box"
                data-test-timer
                data-duration="1800"
                data-test-number="<?= e($application['test_number']) ?>"
            >
                <small>Sisa waktu</small>
                <strong>
                    <span data-minutes>30</span>:<span data-seconds>00</span>
                </strong>
            </div>
        </div>

        <?php if ($totalQuestions === 0): ?>
            <div class="panel">
                <h2>Soal belum tersedia</h2>
                <p>Silakan hubungi pengelola PMB untuk informasi lebih lanjut.</p>
            </div>
        <?php else: ?>
            <form
                method="post"
                action="submit_test.php"
                class="test-form"
                data-test-form
            >
                <?php $number = 1; ?>

                <?php while ($question = $questions->fetch_assoc()): ?>
                    <article class="question-card">
                        <div class="question-meta">
                            <span>Soal <?= $number ?></span>
                            <span>Wajib dijawab</span>
                        </div>

                        <h3><?= e($question['question']) ?></h3>

                        <div class="option-list">
                            <?php foreach ([
                                'a' => $question['option_a'],
                                'b' => $question['option_b'],
                                'c' => $question['option_c'],
                                'd' => $question['option_d'],
                            ] as $key => $text): ?>
                                <label class="option-row">
                                    <input
                                        type="radio"
                                        name="answers[<?= (int) $question['id'] ?>]"
                                        value="<?= $key ?>"
                                        required
                                    >
                                    <span>
                                        <strong><?= strtoupper($key) ?>.</strong>
                                        <?= e($text) ?>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </article>

                    <?php $number++; ?>
                <?php endwhile; ?>

                <div class="test-submit-bar">
                    <div class="test-submit-note">
                        <?= (int) $totalQuestions ?> soal • Periksa jawaban sebelum mengirim.
                    </div>
                    <button class="btn primary" type="submit">
                        Kirim Jawaban &amp; Selesai
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </section>

    <script defer src="<?= $baseUrl ?>/assets/js/test-timer.js"></script>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
