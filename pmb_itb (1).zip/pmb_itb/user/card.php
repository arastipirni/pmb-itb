<?php
/**
 * Kegunaan: Menampilkan kartu penerimaan mahasiswa setelah diterima.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

$stmt = $conn->prepare(
    'SELECT u.name, u.email, a.nim, a.test_number, '
    . 'm.name AS major_name, m.faculty '
    . 'FROM users u '
    . 'JOIN applications a ON a.user_id = u.id '
    . 'LEFT JOIN majors m ON a.major_id = m.id '
    . 'WHERE u.id = ? LIMIT 1'
);
$userId = $_SESSION['user_id'];
$stmt->bind_param('i', $userId);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

$pageTitle = 'Kartu Mahasiswa';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="section-block narrow">
    <div class="student-card">
        <div class="student-card-head">
            <img
                src="<?= $baseUrl ?>/assets/images/itb-logo.png"
                alt="Logo ITB"
            >
            <div>
                <strong>INSTITUT TEKNOLOGI BANDUNG</strong>
                <small>Kartu Penerimaan Mahasiswa</small>
            </div>
        </div>

        <div class="student-card-body">
            <p><span>Nama</span><?= e($data['name']) ?></p>
            <p><span>Email</span><?= e($data['email']) ?></p>
            <p><span>Nomor Tes</span><?= e($data['test_number']) ?></p>
            <p><span>Program Studi</span><?= e($data['major_name']) ?></p>
            <p><span>Fakultas/Sekolah</span><?= e($data['faculty']) ?></p>
            <p><span>NIM</span><?= e($data['nim']) ?></p>
        </div>

        <button
            class="btn primary print-button"
            onclick="window.print()"
        >
            Cetak / Simpan PDF
        </button>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
