<?php
/**
 * Kegunaan: Menampilkan pengumuman PMB yang dibuat oleh Admin.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_login();

if (is_admin()) {
    redirect('/pmb_itb/admin/index.php');
}

$items = $conn->query(
    'SELECT title, content, created_at FROM announcements '
    . 'WHERE is_active = 1 ORDER BY created_at DESC'
);

$pageTitle = 'Pengumuman PMB';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="section-block">
    <div class="section-heading">
        <span class="eyebrow">Informasi</span>
        <h1>Pengumuman PMB</h1>
    </div>

    <div class="card-grid">
        <?php while ($item = $items->fetch_assoc()): ?>
            <article class="feature-card">
                <small><?= e($item['created_at']) ?></small>
                <h2><?= e($item['title']) ?></h2>
                <p><?= nl2br(e($item['content'])) ?></p>
            </article>
        <?php endwhile; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
