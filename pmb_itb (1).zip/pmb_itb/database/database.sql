CREATE DATABASE IF NOT EXISTS pmb_itb
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE pmb_itb;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS activity_logs;
DROP TABLE IF EXISTS test_answers;
DROP TABLE IF EXISTS test_attempts;
DROP TABLE IF EXISTS re_registrations;
DROP TABLE IF EXISTS announcements;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS majors;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE majors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    faculty VARCHAR(180) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    major_id INT NULL,
    test_number VARCHAR(30) UNIQUE,
    status ENUM(
        'registered',
        'tested',
        'passed',
        'failed',
        're_registered',
        'accepted'
    ) NOT NULL DEFAULT 'registered',
    phone VARCHAR(30),
    birth_date DATE NULL,
    gender ENUM('L', 'P') NULL,
    address TEXT,
    school VARCHAR(180),
    test_score INT DEFAULT 0,
    test_date DATETIME NULL,
    nim VARCHAR(30) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_app_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_app_major
        FOREIGN KEY (major_id) REFERENCES majors(id)
        ON DELETE SET NULL
);

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    option_a VARCHAR(255) NOT NULL,
    option_b VARCHAR(255) NOT NULL,
    option_c VARCHAR(255) NOT NULL,
    option_d VARCHAR(255) NOT NULL,
    correct_answer CHAR(1) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE test_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    application_id INT NOT NULL,
    score INT NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (application_id) REFERENCES applications(id)
        ON DELETE CASCADE
);

CREATE TABLE test_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    attempt_id INT NOT NULL,
    question_id INT NOT NULL,
    selected_answer CHAR(1) NOT NULL,
    is_correct TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (attempt_id) REFERENCES test_attempts(id)
        ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id)
        ON DELETE CASCADE
);

CREATE TABLE re_registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL UNIQUE,
    payment_note TEXT,
    status ENUM('submitted', 'approved', 'rejected')
        NOT NULL DEFAULT 'submitted',
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at DATETIME NULL,
    FOREIGN KEY (application_id) REFERENCES applications(id)
        ON DELETE CASCADE
);

CREATE TABLE announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(180) NOT NULL,
    content TEXT NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL,
    subject VARCHAR(180) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('unread', 'read') NOT NULL DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL
);

CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(180) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL
);

INSERT INTO users (name, email, password, role)
VALUES (
    'Administrator PMB ITB',
    'InstitutTeknologiBandung@gmail.com',
    '$2y$12$Z4pJEEqrxwikrbizP5qeqeQlNH5mbph0xS7rzQejlaETuN/WRMps.',
    'admin'
);

INSERT INTO majors (code, name, faculty) VALUES
('ME', 'Meteorologi', 'Fakultas Ilmu dan Teknologi Kebumian (FITB)'),
('OS', 'Oseanografi', 'Fakultas Ilmu dan Teknologi Kebumian (FITB)'),
('GD', 'Teknik Geodesi dan Geomatika', 'Fakultas Ilmu dan Teknologi Kebumian (FITB)'),
('GL', 'Teknik Geologi', 'Fakultas Ilmu dan Teknologi Kebumian (FITB)'),
('AK', 'Aktuaria', 'Fakultas Matematika dan Ilmu Pengetahuan Alam (FMIPA)'),
('AS', 'Astronomi', 'Fakultas Matematika dan Ilmu Pengetahuan Alam (FMIPA)'),
('FI', 'Fisika', 'Fakultas Matematika dan Ilmu Pengetahuan Alam (FMIPA)'),
('KI', 'Kimia', 'Fakultas Matematika dan Ilmu Pengetahuan Alam (FMIPA)'),
('MA', 'Matematika', 'Fakultas Matematika dan Ilmu Pengetahuan Alam (FMIPA)'),
('DI', 'Desain Interior', 'Fakultas Seni Rupa dan Desain (FSRD)'),
('DKV', 'Desain Komunikasi Visual', 'Fakultas Seni Rupa dan Desain (FSRD)'),
('DP', 'Desain Produk', 'Fakultas Seni Rupa dan Desain (FSRD)'),
('KR', 'Kriya', 'Fakultas Seni Rupa dan Desain (FSRD)'),
('SR', 'Seni Rupa', 'Fakultas Seni Rupa dan Desain (FSRD)'),
('AE', 'Teknik Dirgantara', 'Fakultas Teknik Mesin dan Dirgantara (FTMD)'),
('MT', 'Teknik Material', 'Fakultas Teknik Mesin dan Dirgantara (FTMD)'),
('MS', 'Teknik Mesin', 'Fakultas Teknik Mesin dan Dirgantara (FTMD)'),
('TG', 'Teknik Geofisika', 'Fakultas Teknik Pertambangan dan Perminyakan (FTTM)'),
('MG', 'Teknik Metalurgi', 'Fakultas Teknik Pertambangan dan Perminyakan (FTTM)'),
('TM', 'Teknik Perminyakan', 'Fakultas Teknik Pertambangan dan Perminyakan (FTTM)'),
('TA', 'Teknik Pertambangan', 'Fakultas Teknik Pertambangan dan Perminyakan (FTTM)'),
('IL', 'Rekayasa Infrastruktur Lingkungan', 'Fakultas Teknik Sipil dan Lingkungan (FTSL)'),
('SA', 'Teknik dan Pengelolaan Sumber Daya Air', 'Fakultas Teknik Sipil dan Lingkungan (FTSL)'),
('KL', 'Teknik Kelautan', 'Fakultas Teknik Sipil dan Lingkungan (FTSL)'),
('TL', 'Teknik Lingkungan', 'Fakultas Teknik Sipil dan Lingkungan (FTSL)'),
('SI', 'Teknik Sipil', 'Fakultas Teknik Sipil dan Lingkungan (FTSL)'),
('MR', 'Manajemen Rekayasa Industri', 'Fakultas Teknologi Industri (FTI)'),
('TB', 'Teknik Bioenergi dan Kemurgi', 'Fakultas Teknologi Industri (FTI)'),
('TF', 'Teknik Fisika', 'Fakultas Teknologi Industri (FTI)'),
('TI', 'Teknik Industri', 'Fakultas Teknologi Industri (FTI)'),
('TK', 'Teknik Kimia', 'Fakultas Teknologi Industri (FTI)'),
('PG', 'Teknik Pangan', 'Fakultas Teknologi Industri (FTI)'),
('AR', 'Arsitektur', 'Sekolah Arsitektur, Perencanaan dan Pengembangan Kebijakan (SAPPK)'),
('PWK', 'Perencanaan Wilayah dan Kota', 'Sekolah Arsitektur, Perencanaan dan Pengembangan Kebijakan (SAPPK)'),
('MK', 'Kewirausahaan', 'Sekolah Bisnis dan Manajemen (SBM)'),
('MB', 'Manajemen', 'Sekolah Bisnis dan Manajemen (SBM)'),
('FKK', 'Farmasi Klinik dan Komunitas', 'Sekolah Farmasi (SF)'),
('FA', 'Sains dan Teknologi Farmasi', 'Sekolah Farmasi (SF)'),
('BI', 'Biologi', 'Sekolah Ilmu dan Teknologi Hayati (SITH)'),
('BM', 'Mikrobiologi', 'Sekolah Ilmu dan Teknologi Hayati (SITH)'),
('BE', 'Rekayasa Hayati', 'Sekolah Ilmu dan Teknologi Hayati (SITH)'),
('BA', 'Rekayasa Pertanian', 'Sekolah Ilmu dan Teknologi Hayati (SITH)'),
('BW', 'Rekayasa Kehutanan', 'Sekolah Ilmu dan Teknologi Hayati (SITH)'),
('BP', 'Teknologi Pascapanen', 'Sekolah Ilmu dan Teknologi Hayati (SITH)'),
('II', 'Sistem dan Teknologi Informasi', 'Sekolah Teknik Elektro dan Informatika (STEI)'),
('EB', 'Teknik Biomedis', 'Sekolah Teknik Elektro dan Informatika (STEI)'),
('EL', 'Teknik Elektro', 'Sekolah Teknik Elektro dan Informatika (STEI)'),
('IF', 'Informatika', 'Sekolah Teknik Elektro dan Informatika (STEI)'),
('ET', 'Teknik Telekomunikasi', 'Sekolah Teknik Elektro dan Informatika (STEI)'),
('EP', 'Teknik Tenaga Listrik', 'Sekolah Teknik Elektro dan Informatika (STEI)');

INSERT INTO questions (
    question,
    option_a,
    option_b,
    option_c,
    option_d,
    correct_answer
) VALUES
(
    'Dalam PPLG atau RPL, HTML terutama digunakan untuk ...',
    'Menyusun struktur dan isi dasar halaman web',
    'Mengatur koneksi komputer ke internet',
    'Menggantikan seluruh fungsi database',
    'Membuat sistem operasi',
    'a'
),
(
    'CSS pada sebuah website digunakan terutama untuk ...',
    'Mengatur tampilan, warna, jarak, dan tata letak halaman',
    'Menyimpan password pengguna ke database',
    'Menggantikan HTML pada semua bagian web',
    'Menghapus file yang rusak secara otomatis',
    'a'
),
(
    'JavaScript pada halaman web biasanya digunakan untuk ...',
    'Membuat interaksi dan perilaku halaman menjadi dinamis',
    'Menambah kapasitas RAM komputer',
    'Mengganti sistem operasi',
    'Mencetak dokumen tanpa perangkat lain',
    'a'
),
(
    'Dalam HTML, tag <a> umumnya digunakan untuk ...',
    'Membuat tautan atau hyperlink menuju halaman atau sumber lain',
    'Membuat gambar menjadi lebih tajam',
    'Menyimpan data ke MySQL secara langsung',
    'Membuat komputer terhubung ke Wi-Fi',
    'a'
),
(
    'Jika warna tombol website ingin diubah menjadi biru dan ukurannya diperbesar, teknologi yang paling tepat digunakan adalah ...',
    'HTML saja',
    'CSS',
    'MySQL',
    'Git',
    'b'
),
(
    'Seorang siswa PPLG membuat program tetapi hasilnya berbeda dari yang diharapkan. Langkah awal debugging yang paling tepat adalah ...',
    'Menghapus seluruh kode lalu memulai tanpa membaca error',
    'Memeriksa pesan error, bagian kode yang terkait, dan alur program secara bertahap',
    'Menyalin program orang lain tanpa memahami penyebab masalah',
    'Mengganti semua nama variabel sekaligus',
    'b'
),
(
    'Bahasa pemrograman yang sering digunakan untuk membuat logika sisi server pada aplikasi web sederhana adalah ...',
    'PHP',
    'HTML',
    'CSS',
    'Figma',
    'a'
),
(
    'MySQL dalam project PPLG atau RPL digunakan terutama untuk ...',
    'Mengelola dan menyimpan data dalam database',
    'Mengatur warna tampilan halaman',
    'Membuat animasi tanpa kode',
    'Menggantikan fungsi browser',
    'a'
),
(
    'Git dalam pengembangan perangkat lunak berguna untuk ...',
    'Mencatat versi perubahan kode dan membantu kolaborasi tim',
    'Mengubah monitor menjadi lebih besar',
    'Menghapus semua bug secara otomatis',
    'Meningkatkan kecepatan internet',
    'a'
),
(
    'Dalam pengembangan game, pengujian (testing) dilakukan untuk ...',
    'Menemukan bug dan memastikan fitur permainan berjalan sesuai rancangan',
    'Menghilangkan kebutuhan desain game',
    'Membuat semua pemain menjadi admin',
    'Mengganti seluruh kode dengan gambar',
    'a'
),
(
    'Ketika akan memasuki perguruan tinggi, kamu memiliki beberapa tugas dan kegiatan dengan jadwal yang berdekatan. Sikap yang paling tepat adalah ...',
    'Menyusun prioritas berdasarkan tenggat, pentingnya kegiatan, dan waktu yang tersedia',
    'Mengerjakan semuanya tanpa urutan agar terasa cepat',
    'Menunggu teman menentukan apa yang harus dikerjakan',
    'Mengabaikan tugas yang sulit',
    'a'
),
(
    'Jika kamu mendapatkan materi yang belum dipahami, kebiasaan belajar yang paling baik adalah ...',
    'Mencari sumber belajar tambahan, mencoba memahami konsep, lalu bertanya dengan pertanyaan yang spesifik',
    'Menyalin jawaban tanpa memahami materi',
    'Menghindari materi sampai ujian',
    'Menghafal semua istilah tanpa memahami hubungan antarkonsep',
    'a'
),
(
    'Dalam kerja kelompok, pembagian tugas yang sehat sebaiknya dilakukan dengan cara ...',
    'Membagi tugas sesuai kesepakatan, kemampuan, tanggung jawab, dan batas waktu yang jelas',
    'Memberikan semua tugas kepada anggota yang paling pintar',
    'Membiarkan satu anggota mengerjakan semuanya',
    'Tidak menentukan siapa yang bertanggung jawab',
    'a'
),
(
    'Saat menemukan perbedaan pendapat dalam diskusi, tindakan yang menunjukkan kemampuan berpikir kritis adalah ...',
    'Mendengarkan alasan, memeriksa bukti, lalu menyampaikan pendapat dengan sopan',
    'Menganggap pendapat sendiri selalu paling benar',
    'Mengikuti pendapat terbanyak tanpa mempertimbangkan alasannya',
    'Menghentikan diskusi agar tidak ada perbedaan',
    'a'
),
(
    'Sebelum menggunakan informasi dari internet untuk tugas, sebaiknya kamu ...',
    'Memeriksa sumber, penulis, konteks, dan kebenaran informasi tersebut',
    'Langsung menyalin semua isi halaman',
    'Menghilangkan nama sumber agar terlihat sebagai hasil sendiri',
    'Menganggap semua informasi di internet pasti benar',
    'a'
),
(
    'Contoh perilaku yang mencerminkan integritas akademik adalah ...',
    'Mengerjakan tugas secara jujur dan mencantumkan sumber yang digunakan',
    'Menyalin tugas orang lain tanpa izin',
    'Membagikan jawaban ujian kepada teman',
    'Mengubah sedikit kalimat dari sumber lalu mengaku sebagai karya sendiri',
    'a'
),
(
    'Jika kamu harus menghubungi dosen atau pengajar melalui email, komunikasi yang paling tepat adalah ...',
    'Menggunakan bahasa sopan, memperkenalkan diri, menjelaskan tujuan dengan jelas, dan memberi konteks yang cukup',
    'Menggunakan singkatan seperti chat dengan teman',
    'Mengirim pesan kosong lalu menunggu balasan',
    'Mengirim pesan berkali-kali dalam waktu singkat',
    'a'
),
(
    'Ketika menerima kritik terhadap hasil pekerjaanmu, respons yang paling konstruktif adalah ...',
    'Mencari bagian yang perlu diperbaiki dan menggunakan kritik sebagai bahan evaluasi',
    'Menolak semua kritik tanpa memeriksanya',
    'Menyalahkan anggota kelompok lain',
    'Menghapus hasil kerja tanpa mencari tahu masalahnya',
    'a'
),
(
    'Saat mulai belajar di lingkungan perguruan tinggi, kemampuan yang paling membantu untuk berkembang secara mandiri adalah ...',
    'Mampu mencari sumber belajar, mencoba solusi, mengevaluasi hasil, dan meminta bantuan saat diperlukan',
    'Selalu menunggu instruksi untuk setiap langkah kecil',
    'Menghindari tugas yang belum pernah dicoba',
    'Hanya belajar ketika akan ada ujian',
    'a'
),
(
    'Kamu tertarik mengikuti organisasi atau kegiatan kampus, tetapi juga memiliki banyak kewajiban akademik. Pilihan yang paling bijak adalah ...',
    'Memilih kegiatan secara realistis dan mengatur waktu agar kewajiban akademik tetap terpenuhi',
    'Mengikuti semua kegiatan tanpa membuat jadwal',
    'Mengurangi waktu belajar agar bisa mengikuti semua acara',
    'Menolak semua kegiatan tanpa mempertimbangkan manfaatnya',
    'a'
);


INSERT INTO announcements (title, content) VALUES
(
    'Selamat Datang di PMB ITB',
    'Silakan membuat akun, melengkapi profil, dan mengikuti alur pendaftaran.'
),
(
    'Persiapkan Data Pribadi',
    'Pastikan nama, asal sekolah, nomor HP, alamat, dan pilihan program studi sudah benar.'
);
