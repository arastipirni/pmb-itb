<?php
/**
 * Kegunaan: Menampilkan landing page PMB dengan informasi,
 * alur pendaftaran, keunggulan, dan tombol aksi calon mahasiswa.
 */

$pageTitle = 'PMB ITB - Penerimaan Mahasiswa Baru';
require_once __DIR__ . '/includes/header.php';
?>

<section class="hero">
    <div class="hero-content">
        <span class="eyebrow">Pendaftaran Mahasiswa Baru</span>
        <h1>
            Mulai perjalananmu menjadi mahasiswa
            Institut Teknologi Bandung
        </h1>
        <p>
           Pendaftaran Mahasiswa Baru Institut Teknologi Bandung
           memudahkan calon mahasiswa menjalani proses registrasi,
           pengisian profil, nomor tes, kartu ujian, tes seleksi, 
           pengumuman hasil, hingga daftar ulang dalam satu alur.

        <div class="hero-actions">
            <a
                class="btn light"
                href="<?= $baseUrl ?>/auth/register.php"
            >
                Daftar Sekarang
            </a>
            <a
                class="btn secondary"
                href="<?= $baseUrl ?>/auth/login.php"
            >
                Login Pendaftar
            </a>
        </div>
    </div>

    <div class="hero-card">
        <img
            src="<?= $baseUrl ?>/assets/images/itb-logo.png"
            alt="Logo Institut Teknologi Bandung"
        >
        <h2>Proses utama PMB</h2>
        <ol>
            <li>Buat akun dan login</li>
            <li>Lengkapi profil serta prodi</li>
            <li>Dapatkan nomor tes</li>
            <li>Cetak kartu ujian</li>
            <li>Ikuti tes dan tunggu hasil</li>
            <li>Daftar ulang sampai memperoleh NIM</li>
        </ol>
    </div>
</section>

<section class="section-block" id="informasi">
    <div class="section-heading">
        <span class="eyebrow">Informasi</span>
        <h2>Informasi penting tersaji dalam satu dashboard</h2>
        <p>
            Setelah login, setiap calon mahasiswa dapat melihat status
            pendaftaran dan langkah yang masih harus diselesaikan.
        </p>
    </div>

    <div class="card-grid four">
        <article class="feature-card">
            <h3>Profil Terarah</h3>
            <p>
                Isi biodata, asal sekolah, kontak, dan program studi
                sebelum masuk ke tahap tes.
            </p>
        </article>

        <article class="feature-card">
            <h3>Kartu Ujian</h3>
            <p>
                Nomor tes digunakan untuk membuat kartu ujian yang bisa
                dicetak sebelum mengikuti tes.
            </p>
        </article>

        <article class="feature-card">
            <h3>Tes Berwaktu</h3>
            <p>
                Soal pilihan ganda tampil rapi dengan timer agar suasana
                seleksi terasa lebih terstruktur.
            </p>
        </article>

        <article class="feature-card">
            <h3>Hasil & Daftar Ulang</h3>
            <p>
                Setelah hasil tes tersedia, proses daftar ulang dan NIM
                dipantau dari akun yang sama.
            </p>
        </article>
    </div>
</section>

<section class="section-block" id="alur">
    <div class="section-heading">
        <span class="eyebrow">Alur Pendaftaran</span>
        <h2>Dari Registrasi hingga Memperoleh Kartu Ujian</h2>
        <p>
           Berikut tahapan yang harus dilalui calon mahasiswa dalam proses Penerimaan Mahasiswa Baru.
        </p>
    </div>

    <div class="process-grid">
        <article class="process-step">
            <div class="process-number">01</div>
            <h3>Buat Akun</h3>
            <p>
                Daftarkan nama, email, dan password untuk membuat akun calon
                mahasiswa.
            </p>
        </article>

        <article class="process-step">
            <div class="process-number">02</div>
            <h3>Login</h3>
            <p>
                Masuk ke dashboard untuk melihat seluruh tahapan yang harus
                diselesaikan.
            </p>
        </article>

        <article class="process-step">
            <div class="process-number">03</div>
            <h3>Lengkapi Profil</h3>
            <p>
                Isi biodata, asal sekolah, kontak, dan pilih program studi.
            </p>
        </article>

        <article class="process-step">
            <div class="process-number">04</div>
            <h3>Nomor Tes</h3>
            <p>
                Setelah profil tersimpan, sistem memberikan nomor tes unik.
            </p>
        </article>

        <article class="process-step">
            <div class="process-number">05</div>
            <h3>Kartu Ujian</h3>
            <p>
                Buka menu kartu ujian untuk melihat detail peserta dan
                mencetak kartu.
            </p>
        </article>

        <article class="process-step">
            <div class="process-number">06</div>
            <h3>Ikuti Tes</h3>
            <p>
                Kerjakan pilihan ganda dengan waktu yang ditampilkan di layar.
            </p>
        </article>

        <article class="process-step">
            <div class="process-number">07</div>
            <h3>Lihat Hasil</h3>
            <p>
                Sistem menentukan status kelulusan setelah peserta menyelesaikan tes.
            </p>
        </article>

        <article class="process-step">
            <div class="process-number">08</div>
            <h3>Daftar Ulang</h3>
            <p>
                Peserta yang lulus dapat mengajukan daftar ulang hingga admin
                memberikan NIM.
            </p>
        </article>
    </div>
</section>

<section class="section-block">
    <div class="split-section">
        <div class="callout">
            <span class="eyebrow">Tips Pendaftar</span>
            <h3>Lengkapi profil sebelum membuka tahap tes</h3>
            <p>
                Pastikan data pribadi, asal sekolah, kontak, dan program studi
                sudah benar. Data ini juga digunakan untuk menampilkan kartu
                ujian dan informasi penerimaan.
            </p>
            <a
                class="btn primary"
                href="<?= $baseUrl ?>/auth/register.php"
            >
                Mulai Pendaftaran
            </a>
        </div>

        <div class="panel">
            <div class="panel-heading">
                <h2>Persiapan Sebelum Tes</h2>
            </div>
            <div class="data-grid">
                <div>
                    <span>01</span>
                    <strong>Periksa nomor tes</strong>
                </div>
                <div>
                    <span>02</span>
                    <strong>Cetak atau simpan kartu ujian</strong>
                </div>
                <div>
                    <span>03</span>
                    <strong>Gunakan koneksi internet yang stabil</strong>
                </div>
                <div>
                    <span>04</span>
                    <strong>Selesaikan soal sebelum timer berakhir</strong>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-block">
    <div class="section-heading">
        <span class="eyebrow">Ringkas & Jelas</span>
        <h2>Seluruh Tahapan dalam Satu Akun</h2>
    </div>

    <div class="kpi-row">
        <div class="kpi-card">
            <span>Proses Pendaftaran</span>
            <strong>Online</strong>
            <span>Seluruh proses pendaftaran dilakukan secara online,
                 mulai dari registrasi hingga daftar ulang.
            </span>
        </div>

        <div class="kpi-card">
            <span>Pelaksanaan Seleksi</span>
            <strong>Pilihan Ganda</strong>
            <span>Peserta mengikuti tes seleksi sesuai jadwal yang telah ditentukan.</span>
        </div>

        <div class="kpi-card">
            <span>Akses Informasi</span>
            <strong>Dashboard</strong>
            <span>Status pendaftaran dan tahapan berikutnya dapat dipantau melalui dashboard.</span>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
